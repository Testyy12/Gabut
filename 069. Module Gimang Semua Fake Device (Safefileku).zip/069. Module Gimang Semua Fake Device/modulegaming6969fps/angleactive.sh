[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Angle Driver"

sleep 2

angle_allapp() {
settings put global angle_debug_package org.chromium.angle 
settings put global angle_gl_driver_all_angle 1 
settings put global angle.supported 1 
settings put global angle_gl_driver_selection_values angle 
settings put global angle_enabled_app org.chromium.angle 
}

angle_allapp > /dev/null 2>&1 

sleep 2

echo "Done Installing Angle Driver"

sleep 2

echo "Wajib Restart Dan Jalankan tweakangle.sh"
