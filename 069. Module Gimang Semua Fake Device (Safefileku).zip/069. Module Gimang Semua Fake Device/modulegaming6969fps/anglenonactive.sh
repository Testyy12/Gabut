[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Removing Angle Setting"

sleep 2

angle_remove() {
angle_allapp() {
settings delete global angle_debug_package 
settings delete global angle_gl_driver_all_angle 
settings delete global angle.supported 
settings delete global angle_gl_driver_selection_values 
settings delete global angle_enabled_app 
}

angle_remove > /dev/null 2>&1 

sleep 2

echo "Angle Setting Removed"

sleep 2

echo "Setelah Uninstal Wajib Reboot"
