[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Tweak Anti Aliasing"

sleep 2

#Tweaks
set_tweakrender() {
setprop debug.egl.force_msaa 1 
setprop debug.egl.force_fxaa 1 
setprop debug.egl.force_taa 1 
}
set_tweakrender > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

sleep 2

echo "Done Installing Anti Aliasing"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
