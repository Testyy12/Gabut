[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      Black Shark 5 Pro      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Fake Device"

sleep 2

fake_device() {
settings put global device_name Black-Shark-5-Pro
settings put global device_device katyusha 
settings put global device_model SHARK KTUS-H0 
settings put global device_brand blackshark 
settings put global device_manufacturer blackshark 
settings put global persist.sys.tran.device.name Black-Shark-5-Pro 
}

fake_device > /dev/null 2>&1 

sleep 2

echo "Done Installing Fake Device"

sleep 2

echo "Selamat Gimang 6969 Ngefies"
