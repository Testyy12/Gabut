[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Storage Faster"

sleep 2

#Tweaks
set_rambooster() {
setprop debug.doze.component 1 
}
set_rambooster > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#Fstrim Everyboot
set_fsrim_interval() {
settings put global fstrim_mandatory_interval 1 
}
set_fsrim_interval > /dev/null 2>&1 

#Cache Trim
set_cache_trim() {
pm trim-caches 9999999999999999999999999999999 
}
set_cache_trim > /dev/null 2>&1 

#Gmz Doze
run() {
pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver 
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver 
dumpsys deviceidle whitelist -com.google.android.gms 
}

run > /dev/null 2>&1 

sleep 2

echo "Done Installing Storage Faster"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
