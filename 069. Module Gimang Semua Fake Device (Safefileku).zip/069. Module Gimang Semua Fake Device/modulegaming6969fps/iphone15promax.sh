[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 15 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Fake Device"

sleep 2

fake_device() {
settings put global device_name iPhone-15-Pro-Max 
settings put global device_device iPhone16,2 
settings put global device_model A2849 
settings put global device_brand apple 
settings put global device_manufacturer apple 
settings put global persist.sys.tran.device.name iPhone-15-Pro-Max  
}

fake_device > /dev/null 2>&1 

sleep 2

echo "Done Installing Fake Device"

sleep 2

echo "Selamat Gimang 6969 Ngefies"
