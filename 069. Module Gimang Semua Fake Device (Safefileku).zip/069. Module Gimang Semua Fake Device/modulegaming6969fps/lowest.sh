[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Graphics Lowest"

sleep 2

#Tweaks
set_perforfmance() {
setprop debug.egl.profiler 0 
setprop debug.egl.hw 0 
setprop debug.egl.force_msaa 0 
setprop debug.egl.force_fxaa 0 
setprop debug.egl.force_taa 0 
setprop debug.gralloc.gfx_ubwc_disable 1 
setprop debug.gfx.driver 0 
setprop debug.hwui.multi_renderer.use 1 
setprop debug.hwui.level 0 
setprop debug.hwui.skia_atrace_enabled 0
setprop debug.hwui.render_dirty_regions 0
setprop debug.hwui.disable_vsync 1
setprop debug.hwui.show_dirty_regions 0 
setprop debug.hwui.use_gpu_pixel_buffers 1 
setprop debug.hwui.use_buffer_age 1 
setprop debug.hwui.skip_empty_damage 0 
setprop debug.hwui.use_partial_updates 0 
setprop debug.hwui.enable_partial_updates 0 
setprop debug.mdpcomp.logs 0 
setprop debug.qsg_renderer 0 
setprop debug.renderer.process 1 
setprop debug.rs.rsov 1 
setprop debug.rs.script 0 
setprop debug.rs.shader.attributes 1 
setprop debug.rs.shader.uniforms 1 
setprop debug.rs.visual 0 
setprop debug.rs.default-CPU-driver 1 
setprop debug.rs.default-GPU-driver 1 
setprop debug.rs.default-CPU-buffer 262144 
setprop debug.rs.precision rs_fp_full 
setprop debug.rs.max-threads 8 
setprop debug.rs.min-threads 8 
setprop debug.overlayui.enable 0 
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 1 
setprop debug.sf.hwc_hdcp_via_neg_vsync 1 
setprop debug.sf.set_binder_thread_rt 1 
setprop debug.sf.showcpu 0 
setprop debug.sf.showupdates 0 
setprop debug.sf.showbackground 0 
setprop debug.sf.showfps 0 
setprop debug.sf.hw 0 
setprop debug.sf.enable_hgl 0 
setprop debug.sf.ddms 1 
setprop debug.sf.dump 0 
setprop debug.sf.set_idle_timer_ms 0 
setprop debug.sf.treat_170m_as_sRGB 0 
setprop debug.sf.max_igbp_list_size 0 
setprop debug.sf.disable_hwc_vds 1 
setprop debug.sf.enable_egl_image_tracker 1 
setprop debug.sf.luma_sampling 1 
setprop debug.sf.disable_client_composition_cache 0 
setprop debug.sf.enable_advanced_sf_phase_offset 0 
setprop debug.sf.enable_gl_backpressure 0 
setprop debug.sf.disable_backpressure 1 
setprop debug.sf.latch_unsignaled 0 
setprop debug.sf.gpu_freq_index 7 
setprop debug.sf.auto_latch_unsignaled 0 
setprop debug.sf.enable_hwc_vds 0 
setprop debug.sf.show_predicted_vsync 0 
setprop debug.sf.predict_hwc_composition_strategy 0 
setprop debug.sf.kernel_idle_timer_update_overlay 1 
setprop debug.sf.support_kernel_idle_timer_enabled 0 
setprop debug.sf.vsync_reactor_ignore_present_fences 0 
setprop debug.sf.enable_transaction_tracing 0 
setprop debug.sf.use_phase_offsets_as_durations 0 
setprop debug.sf.ignore_hwc_physical_display_orientation 0 
setprop debug.sf.enable_adpf_cpu_hint 1 
setprop debug.sf.frame_rate_multiple_threshold 144 
setprop debug.sf_frame_rate_multiple_fences 144 
setprop debug.sf.early.app.duration 20000000 
setprop debug.sf.early.sf.duration 27600000 
setprop debug.sf.hwc.min.duration 23000000 
setprop debug.sf.late.app.duration 20000000 
setprop debug.sf.late.sf.duration 27600000 
setprop debug.sf.earlyGl.sf.duration 27600000 
setprop debug.sf.144_fps.early.app.duration 8333333 
setprop debug.sf.144_fps.early.sf.duration 11500000 
setprop debug.sf.144_fps.earlyGl.app.duration 8333333 
setprop debug.sf.144_fps.earlyGl.sf.duration 11500000 
setprop debug.sf.144_fps.late.app.duration 8333333 
setprop debug.sf.144_fps.late.sf.duration 11500000 
setprop debug.sf.high_fps.early.app.duration 10000000 
setprop debug.sf.high_fps.early.sf.duration 13800000 
setprop debug.sf.high_fps.earlyGl.app.duration 10000000 
setprop debug.sf.high_fps.earlyGl.sf.duration 13800000 
setprop debug.sf.high_fps.late.app.duration 10000000 
setprop debug.sf.high_fps.late.sf.duration 13800000 
setprop debug.sf.high_fps.hwc.min.duration 8500000 
setprop debug.sf.high_fps_early_phase_offset_ns 6100000 
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000 
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000 
setprop debug.sf.earlyGl.app.duration 20000000 
setprop debug.sf.early_gl_phase_offset_ns 3000000 
setprop debug.sf.early_gl_app_phase_offset_ns 15000000 
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000 
setprop debug.sf.early_phase_offset_ns 500000 
setprop debug.stagefright.omx_default_rank 1 
setprop debug.stagefright.c2inputsurface -1 
}
set_performance > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#Surface Flinger
set_surface() {
properties=(
  "debug.sf.disable_backpressure 0"
  "debug.sf.hwc_hotplug_error_via_neg_vsync 1"
  "debug.sf.hwc_hdcp_via_neg_vsync 1"
  "debug.sf.set_binder_thread_rt 1"
  "debug.sf.gpu_freq_index 7"
  "debug.sf.ignore_hwc_physical_display_orientation 0"
  "debug.sf.enable_adpf_cpu_hint 1"
  "debug.sf.latch_unsignaled 0"
  "debug.sf.enable_hwc_vds 0"
  "debug.sf.disable_hwc_vds 1"
  "debug.sf.frame_rate_multiple_threshold 144"
  "debug.sf_frame_rate_multiple_fences 144"
  "debug.sf.enable_egl_image_tracker 0"
  "debug.sf.luma_sampling 1"
  "debug.sf.early_phase_offset_ns 500000"
  "debug.sf.auto_latch_unsignaled 0"
  "debug.sf.early.app.duration 20000000"
  "debug.sf.early.sf.duration 27600000"
  "debug.sf.earlyGl.app.duration 20000000"
  "debug.sf.earlyGl.sf.duration 27600000"
  "debug.sf.late.app.duration 20000000"
  "debug.sf.late.sf.duration 27600000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.hwc.min.duration 23000000"
  "debug.sf.enable_gl_backpressure 0"
  "debug.sf.enable_transaction_tracing 0"
  "debug.sf.enable_hgl 0"
  "debug.sf.ddms 1"
  "debug.sf.dump 0"
  "debug.sf.max_igbp_list_size 0"
  "debug.sf.showupdates 0"
  "debug.sf.showcpu 0"
  "debug.sf.showbackground 0"
  "debug.sf.showfps 0"
  "debug.sf.hw 0"
  "debug.sf.disable_client_composition_cache 1"
  "debug.sf.enable_advanced_sf_phase_offset 0"
  "debug.sf.use_phase_offsets_as_durations 0"
  "debug.sf.predict_hwc_composition_strategy 0"
  "debug.sf.treat_170m_as_sRGB 0"
  "debug.sf.set_idle_timer_ms 0"
  "debug.sf.early_gl_phase_offset_ns 3000000"
  "debug.sf.early_gl_app_phase_offset_ns 15000000"
  "debug.sf.high_fps_early_phase_offset_ns 6100000"
  "debug.sf.high_fps_early_gl_phase_offset_ns 650000"
  "debug.sf.high_fps_late_app_phase_offset_ns 100000"
  "debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000"
  "debug.sf.144_fps.early.app.duration 8333333"
  "debug.sf.144_fps.early.sf.duration 11500000"
  "debug.sf.144_fps.earlyGl.app.duration 8333333"
  "debug.sf.144_fps.earlyGl.sf.duration 11500000"
  "debug.sf.144_fps.late.app.duration 8333333"
  "debug.sf.144_fps.late.sf.duration 11500000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.high_fps.late.app.duration 10000000"
  "debug.sf.high_fps.early.sf.duration 13800000"
  "debug.sf.high_fps.early.app.duration 10000000"
  "debug.sf.high_fps.earlyGl.sf.duration 13800000"
  "debug.sf.high_fps.earlyGl.app.duration 10000000"
  "debug.sf.high_fps.hwc.min.duration 8500000"
)

for prop in "${properties[@]}"; do
  setprop $prop
done
}
set_surface > /dev/null 2>&1 

set_surface() {
settings put graphics pixelformat ALPHA_1 
settings put graphics pixelformal 1 
settings put graphics refresh_rate 144 
settings put graphics max_caches 3 
settings put graphics max_texture_atlas_size 128 
settings put graphics max_layers 16 
settings put graphics max_texture_size 128 
settings put graphics max_cpu_usage 3.0 
settings put graphics_sf swapinterval 0 
settings put surfaceflinger native_boot.SkiaTracingFeature__use_skia_tracing 0 
settings put surfaceflinger refresh_rate 144 
settings put surfaceflinger max_frame_buffer_acquired_count 4 
settings put surfaceflinger use_content_detection_for_refresh_rate 1  
settings put surfaceflinger game_default_frame_rate_override 144 
settings put surfaceflinger enable_frame_rate_override 1 
settings put surfaceflinger has_HDR_display 0 
settings put surfaceflinger supports_background_blur 1 
settings put surfaceflinger primary_display_orientation 0 
settings put surfaceflinger force_hwc_copy_for_virtual_displays 0
settings put surfaceflinger protected_contents 0 
settings put surfaceflinger uclamp.min 130 
settings put surfaceflinger has_wide_color_display 0 
settings put surfaceflinger use_color_management 0 
settings put surfaceflinger set_touch_timer_ms 0 
settings put surfaceflinger max_virtual_display_dimension 4096 
settings put surfaceflinger wcg_composition_dataspace 143261696 
settings put surfaceflinger clear_slots_with_set_layer_buffer 0 
settings put surfaceflinger set_idle_timer_ms 0 
settings put surfaceflinger set_display_power_timer_ms 0 
settings put surfaceflinger enable_hwc 0 
settings put surfaceflinger min_swap_interval 0 
settings put surfaceflinger disable_expensive_timestamps 1 
settings put surfaceflinger enable_vds_tweak 0 
settings put surfaceflinger vsync_eventphase_offset_ns 6300000 
settings put surfaceflinger vsync_sfoffset_ns 6300000 
settings put surfaceflinger enable_debug_sf_vs 0
}

set_surface > /dev/null 2>&1 

#DeviceConfig
set_android() { 
cmd device_config put graphics pixelformat ALPHA_1 
cmd device_config put graphics pixelformal 1 
cmd device_config put graphics refresh_rate 144 
cmd device_config put graphics max_caches 3 
cmd device_config put graphics max_texture_atlas_size 128 
cmd device_config put graphics max_layers 16 
cmd device_config put graphics max_texture_size 128 
cmd device_config put graphics max_cpu_usage 3.0 
cmd device_config put graphics_sf swapinterval 0 
cmd device_config put surfaceflinger native_boot.SkiaTracingFeature__use_skia_tracing 0 
cmd device_config put surfaceflinger refresh_rate 144 
cmd device_config put surfaceflinger max_frame_buffer_acquired_count 4 
cmd device_config put surfaceflinger use_content_detection_for_refresh_rate 1  
cmd device_config put surfaceflinger game_default_frame_rate_override 144 
cmd device_config put surfaceflinger enable_frame_rate_override 1 
cmd device_config put surfaceflinger has_HDR_display 0 
cmd device_config put surfaceflinger supports_background_blur 1 
cmd device_config put surfaceflinger primary_display_orientation 0 
cmd device_config put surfaceflinger force_hwc_copy_for_virtual_displays 0 
cmd device_config put surfaceflinger protected_contents 0 
cmd device_config put surfaceflinger uclamp.min 130 
cmd device_config put surfaceflinger has_wide_color_display 0 
cmd device_config put surfaceflinger use_color_management 0 
cmd device_config put surfaceflinger set_touch_timer_ms 0 
cmd device_config put surfaceflinger max_virtual_display_dimension 4096 
cmd device_config put surfaceflinger wcg_composition_dataspace 143261696 
cmd device_config put surfaceflinger clear_slots_with_set_layer_buffer 0 
cmd device_config put surfaceflinger set_idle_timer_ms 0 
cmd device_config put surfaceflinger set_display_power_timer_ms 0 
cmd device_config put surfaceflinger enable_hwc 0 
cmd device_config put surfaceflinger min_swap_interval 0 
cmd device_config put surfaceflinger disable_expensive_timestamps 1 
cmd device_config put surfaceflinger enable_vds_tweak 0 
cmd device_config put surfaceflinger vsync_eventphase_offset_ns 6300000 
cmd device_config put surfaceflinger vsync_sfoffset_ns 6300000 
cmd device_config put surfaceflinger enable_debug_sf_vs 0 
}
set_android > /dev/null 2>&1 

sleep 2

echo "Done Installing Graphics Lowest"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
