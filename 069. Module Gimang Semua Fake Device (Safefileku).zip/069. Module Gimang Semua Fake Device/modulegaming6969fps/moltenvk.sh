[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing moltenvk"

sleep 2

#Tweaks
set_moltenvk() {
setprop debug.hwui.multi_renderer.use 1 
setprop debug.hwui.shadow.renderer moltenvk 
setprop debug.hwui.renderer moltenvk 
setprop debug.renderengine.backend moltenvk 
setprop debug.composition.type moltenvk 
}
set_moltenvk > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

compotision_type() {
settings put global persist.sys.composition.type moltenvk 
}

compotision_type > /dev/null 2>&1 

sleep 2

echo "Done Installing moltenvk"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
