[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Dalvik Hyper Threading"

sleep 2

non_overheat() { 
settings put global persist.sys.dalvik.hyperthreading 1 
settings put global persist.sys.dalvik.multithread 1 
}

non_overheat > /dev/null 2>&1 

#AndroidConfig
dalvikhyper_threading() {
cmd device_config put global persist.sys.dalvik.hyperthreading 1 
cmd device_config put global persist.sys.dalvik.multithread 1
}
dalvikgyper_threading > /dev/null 2>&1 

sleep 2

echo "Done Installing Dalvik Hyper Threading"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
