[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing opengl"

sleep 2

#Tweaks
set_opengl() {
setprop debug.hwui.multi_renderer.use 1 
setprop debug.hwui.shadow.renderer opengl 
setprop debug.hwui.renderer opengl 
setprop debug.renderengine.backend opengl 
setprop debug.composition.type opengl 
}
set_opengl > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

compotision_type() {
settings put global persist.sys.composition.type opengl 
}

compotision_type > /dev/null 2>&1 

sleep 2

echo "Done Installing opengl"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
