[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Tweak Performance"

sleep 2

boost_cpu() {
settings put global persist.cpu.freq.boost 1 
settings put global transsion_game_acceleration 1 
}

boost_cpu > /dev/null 2>&1 

#Tweaks
set_performance() {
setprop debug.app.performance_restricted 1
setprop debug.atrace.app_number 0 
setprop debug.atrace.tags.enableflags 0 
setprop debug.app.performance_restricted 1 
setprop debug.assert 1 
setprop debug.cpuprio 7 
setprop debug.cpurend.vsync 0 
setprop debug.c2.use_dmabufheaps 1 
setprop debug.choreographer.skipwarning 16 
setprop debug.choreographer.callback 120 
setprop debug.dev.ssrm.turbo 1 
setprop debug.dev.addfree 4 
setprop debug.dev.disable_sched_boost 0 
setprop debug.doze.component 0 
setprop debug.disable.hwacc 0 
setprop debug.disable_sched_boost 1 
setprop debug.enable.sglscale 0 
setprop debug.enable.gamed 0 
setprop debug.enable.wl_log 0 
setprop debug.fb.rgb565 1 
setprop debug.force_rtl 0 
setprop debug.fw.bservice_enable 1 
setprop debug.gpurend.vsync 1 
setprop debug.gpuprio 7 
setprop debug.gpu.scheduler_pre.emption 1 
setprop debug.heat_suppression 0 
setprop debug.hwc.otf 0 
setprop debug.hwc_dump_en 0 
setprop debug.hwc.compose_level 0 
setprop debug.hwc.bq_count 3 
setprop debug.hwui.disable_overlays 1 
setprop debug.hwui.multi_renderer.use 1 
setprop debug.hwui.profile.maxframes 240 
setprop debug.hwui.level 0 
setprop debug.hwui.fps_divisor 0 
setprop debug.hwui.disabledither 0 
setprop debug.hwui.use_partial_updates 0 
setprop debug.hwui.disabledither 0 
setprop debug.hwui.target_cpu_time_percent 100 
setprop debug.hwui.target_gpu_time_percent 100 
setprop debug.hwui.use_hint_manager 1 
setprop debug.hwui.disable_draw_reorder 1 
setprop debug.hwui.disable_draw_defer 1 
setprop debug.ioprio 7 
setprop debug.javafx.animation.fullspeed 1 
setprop debug.javafx.animation.framerate 240 
setprop debug.kill_allocating_task 1 
setprop debug.lldb-rpc-server 0 
setprop debug.mali.disable_backend_affinity 1 
setprop debug.mediatek.appgamepq_compress 1 
setprop debug.mdlogger.Running 0 
setprop debug.multicore.processing 1 
setprop debug.mdpcomp.logs 0 
setprop debug.mdlogger.Running 0 
setprop debug.mdpcomp.maxpermixer 0 
setprop debug.mdpcomp.mixedmode.disable 0 
setprop debug.multicore.processing 1 
setprop debug.mediatek.disp_decompress 1 
setprop debug.mtk_tflite.target_nnapi 29 
setprop debug.MB.running 72 
setprop debug.MB.inner.running 24 
setprop debug.OVRManager.cpuLevel 4 
setprop debug.OVRManager.gpuLevel 4 
setprop debug.overlayui.enable 0 
setprop debug.performance.tuning 1 
setprop debug.performance.disturb 0 
setprop debug.performance_schema 1 
setprop debug.perfhudes 1 
setprop debug.performance_schema_max_memory_classes 320 
setprop debug.performance_schema_max_socket_classes 20 
setprop debug.performance_schema_digests_size 9950000 
setprop debug.power_management_mode pref_max 
setprop debug.qctwa.statusbar 1 
setprop debug.qc.hardware 1 
setprop debug.qctwa.preservebuf 1 
setprop debug.qsg_renderer 1 
setprop debug.redroid.fps 240 
setprop debug.rs.rsov 1 
setprop debug.rs.script 0 
setprop debug.rs.shader.attributes 0 
setprop debug.rs.shader.uniforms 0 
setprop debug.rs.visual 0 
setprop debug.rs.default-CPU-driver 1 
setprop debug.rs.default-GPU-driver 1 
setprop debug.rs.default-CPU-buffer 262144 
setprop debug.rs.precision rs_fp_full 
setprop debug.rs.max-threads 8 
setprop debug.rs.min-threads 8 
setprop debug.rambooster.enable 1 
setprop debug.stagefright.omx_default_rank 0 
setprop debug.sdm.support_writeback 1 
setprop debug.sdm.disable_skip_validate 1 
setprop debug.systemui.latency_tracking 0 
setprop debug.stagefright.fps 0 
setprop debug.show_refresh_rate_overlay_spinner 0 
setprop debug.stagefright.c2inputsurface -1 
setprop debug.scenegraph.batching_performance 1 
setprop debug.systemuicompilerfilter speed 
setprop debug.sqlite.journalmode 0 
setprop debug.qualcomm.sns.daemon 0 
setprop debug.qualcomm.sns.libsensor1 0 
setprop debug.vendor.sys.country_for_cam ID 
setprop debug.vendor.sys.oobe.camera_skin brown 
}
set_performance > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#DeviceConfig
set_android() {
cmd device_config put activity_manager min_low_ram_task_aspect_ratio 0.1 
cmd device_config put cpu_power cpu_max_pwr_mgmnt 2.0 
cmd device_config put cpu_power max_cpu_power 2.0 
cmd device_config put gpu gpu_max_pwr_mgmnt 2.0 
cmd device_config put gpu max_gpu_power 2.0 
cmd device_config put dalvik dedupe_strings 1 
cmd device_config put dalvik vm.dexopt.thermal-cutoff 0 
cmd device_config put dalvik dex2oat_max_inference_threads 4 
cmd device_config put dalvik dex2oat_thread_count 4 
cmd device_config put dalvik jit_enable 1 
cmd device_config put dalvik jit_max_threads 4 
cmd device_config put dalvik jit_mode 2 
cmd device_config put dalvik max_threads 8 
cmd device_config put dalvik vm_heapsize 512m 
cmd device_config put global dalvik.vm.dexopt.thermal-cutoff 0 
cmd device_config put graphics refresh_rate 240 
cmd device_config put graphics max_caches 3 
cmd device_config put graphics max_texture_atlas_size 128 
cmd device_config put graphics max_layers 16 
cmd device_config put graphics max_texture_size 128 
cmd device_config put graphics max_cpu_usage 3.0 
cmd device_config put graphics_sf swapinterval 0 
cmd device_config put input filtered_accel_event_rate_hz 200 
cmd device_config put input accel_buffer_depth 2048 
cmd device_config put input accel_buffer_timeout_ms 50 
cmd device_config put input filtered_accel_lpf_coef 0.1 
cmd device_config put input tap_duration 60 
cmd device_config put input gesture_min_time 100 
cmd device_config put input default_key_press_repeat_rate 15 
cmd device_config put input gesture_min_distance 10 
cmd device_config put input touch_screen_sample_interval_ms 5 
cmd device_config put package_native_code optimizable_apps 1 
cmd device_config put thermal high_temp_limit 90 
cmd device_config put thermal low_temp_limit 20 
cmd device_config put thermal dalvik.vm.dexopt.thermal-cutoff 0 
cmd device_config put system pointer_speed 7 
cmd device_config put window_manager hardware_accelerated 1 
}
set_android > /dev/null 2>&1 

sleep 2

echo "Done Installing Tweak Performance"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
