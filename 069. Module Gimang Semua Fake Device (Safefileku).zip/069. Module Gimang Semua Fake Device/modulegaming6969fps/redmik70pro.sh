[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      Redmi K70 Pro      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Fake Device"

sleep 2

fake_device() {
settings put global device_name Redmi-K70 
settings put global device_device rothko 
settings put global device_model 2407FRK8EC 
settings put global device_brand xiaomi 
settings put global device_manufacturer xiaomi 
settings put global persist.sys.tran.device.name Redmi-K70 
}

fake_device > /dev/null 2>&1 

sleep 2

echo "Done Installing Fake Device"

sleep 2

echo "Selamat Gimang 6969 Ngefies"
