[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Bit Render"

sleep 2

bit_reducer() {
settings put global persist.sys.use_64bpp_alpha 1 
settings put global ro.graphics.pixelformat ALPHA_64 
settings put global persist.sys.sf.color_format ALPHA_64 
settings put global ro.minui.pixel_format ALPHA_64 
settings put global persist.sys.ui.enable_64bit_format 1 
settings put graphics pixelformat ALPHA_64
settings put graphics pixelformat 64 
}

bit_reducer > /dev/null 2>&1 

#AndroidConfig
set_android() {
cmd device_config put global persist.sys.use_64bpp_alpha 1 
cmd device_config put global ro.graphics.pixelformat ALPHA_64 
cmd device_config put global persist.sys.sf.color_format ALPHA_64 
cmd device_config put global ro.minui.pixel_format ALPHA_64 
cmd device_config put global persist.sys.ui.enable_64bit_format 1 
}
set_android > /dev/null 2>&1 

sleep 2

echo "Done Installing Bit Render"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
