[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      Samsung Galaxy S24 Ultra      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Fake Device"

sleep 2

fake_device() {
settings put global device_name Galaxy-S24-Ultra 
settings put global device_device SM-S9280 
settings put global device_model SM-S9280 
settings put global device_brand samsung 
settings put global device_manufacturer samsung 
settings put global persist.sys.tran.device.name Galaxy-S24-Ultra 
}

fake_device > /dev/null 2>&1 

sleep 2

echo "Done Installing Fake Device"

sleep 2

echo "Selamat Gimang 6969 Ngefies"
