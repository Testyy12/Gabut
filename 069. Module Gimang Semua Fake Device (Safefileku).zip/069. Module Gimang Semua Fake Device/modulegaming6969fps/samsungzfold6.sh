[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      Samsung Galaxy Z Fold6      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Fake Device"

sleep 2

fake_device() {
settings put global device_name Galaxy-Z-Fold6 
settings put global device_device SM-F9560 
settings put global device_model SM-F9560 
settings put global device_brand samsung 
settings put global device_manufacturer samsung 
settings put global persist.sys.tran.device.name Galaxy-Z-Fold6 
}

fake_device > /dev/null 2>&1 

sleep 2

echo "Done Installing Fake Device"

sleep 2

echo "Selamat Gimang 6969 Ngefies"
