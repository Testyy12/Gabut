[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing skiagl"

sleep 2

#Tweaks
set_skiagl() {
setprop debug.hwui.multi_renderer.use 1 
setprop debug.hwui.shadow.renderer skiagl 
setprop debug.hwui.renderer skiagl 
setprop debug.renderengine.backend skiagl 
setprop debug.composition.type skiagl  
}
set_skiagl > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

compotision_type() {
settings put global persist.sys.composition.type skiagl 
}

compotision_type > /dev/null 2>&1 

sleep 2

echo "Done Installing skiagl"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
