[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Skiavk Tracing"

sleep 2

#Tweaks
set_skiagl() {
setprop debug.hwui.multi_renderer.use 1 
setprop debug.hwui.skia_atrace_enabled 0
setprop debug.hwui.shadow.renderer skiavk 
setprop debug.hwui.renderer skiavk 
setprop debug.renderengine.backend skiavk 
setprop debug.composition.type skiavk 
setprop debug.sf.enable_transaction_tracing 1 
setprop debug.tracing.screen_brightness 0.25659037
setprop debug.tracing.screen_state 2 
}
set_skiagl > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

device_enchanted() {
settings put global persist.sys.perf.topAppRenderThreadBoost.enable 1 
settings put global persist.device_config.surface_flinger_native_boot.SkiaTracingFeature__use_skia_tracing 1 
settings put global persist.device_config.runtime_native.usap_pool_enabled 1
settings put global persist.sys.composition.type skiavk 
}

device_enchanted > /dev/null 2>&1 

set_surface() {
settings put surfaceflinger native_boot.SkiaTracingFeature__use_skia_tracing 1 
}

set_surface > /dev/null 2>&1 

#AndroidConfig
set_android() {
cmd device_config put surfaceflinger native_boot.SkiaTracingFeature__use_skia_tracing 1 
cmd device_config put runtime native.usap_pool_enabled 1 
}
set_android > /dev/null 2>&1 

sleep 2

echo "Done Installing Skiavk Tracing"

sleep 2

echo "Selamat Gimang 6969 Ngefies"
