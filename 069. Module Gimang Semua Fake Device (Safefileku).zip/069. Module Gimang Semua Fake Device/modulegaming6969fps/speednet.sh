[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Tweak Speed Net"

sleep 2

#Tweaks
speed_net() {
setprop debug.gralloc.enable_fb_ubwc 1
}
speed_net > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

net_speed() {
settings put global persist.data_netmgrd_mtu 1500
settings put global persist.telephony.support.ipv6 1
settings put global persist.telephony.support.ipv4 1
settings put global persist.sys.use_dithering 1
settings put global persist.sys.radio.force_lte_ca 1 
settings put global persist.sys.lte_rsrp 0 
settings put global persist.radio.use_se_table_only 1
settings put global persist.radio.data_ltd_sys_ind 1 
settings put global persist.radio.data_con_rprt 1 
settings put global net_speed_on_off 1 
settings put global netstats_enabled 1 
settings put global network_recommendations_enabled 1 
settings put global network_recommendations_package com.google.android.gms 
settings put global network_scoring_ui_enabled 1 
settings put global network_watchlist_enabled 0 
settings put global network_watchlist_last_report_time 1722790800000 
}

net_speed > /dev/null 2>&1 

sleep 2

echo "Done Installing Tweak Speed Net"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
