[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Thermal Service"

sleep 2

#CMD
set_cmd() {
cmd thermalservice override-status 0 
cmd thermalservice dalvik.vm.dexopt.thermal-cutoff 0 
cmd thermal dalvik.vm.dexopt.thermal-cutoff 0 
cmd global dalvik.vm.dexopt.thermal-cutoff 0 
cmd dalvik vm.dexopt.thermal-cutoff 0 
cmd power set-fixed-performance-mode-enabled 1 
cmd power set-adaptive-power-saver-enabled 1 
}
set_cmd > /dev/null 2>&1 

set_thermal() {
settings put thermal high_temp_limit 90 
settings put thermal low_temp_limit 20 
settings put global high_temp_limit 90 
settings put global low_temp_limit 20 
settings put global game_temperature_control 1 
}

set_thermal > /dev/null 2>&1 

#DeviceConfig
set_android() {
cmd device_config put dalvik vm.dexopt.thermal-cutoff 0 
cmd device_config put dalvik dedupe_strings 1 
cmd device_config put dalvik dex2oat_max_inference_threads 4 
cmd device_config put dalvik dex2oat_thread_count 4 
cmd device_config put dalvik jit_enable 1 
cmd device_config put dalvik jit_max_threads 4 
cmd device_config put dalvik jit_mode 2 
cmd device_config put dalvik jit_threshold 1048576 
cmd device_config put dalvik max_threads 8 
cmd device_config put dalvik vm_heapsize 512 
cmd device_config put global dalvik.vm.dexopt.thermal-cutoff 0 
cmd device_config put thermal dalvik.vm.dexopt.thermal-cutoff 0 
cmd device_config put thermal high_temp_limit 90 
cmd device_config put thermal low_temp_limit 20 
}
set_android > /dev/null 2>&1 

sleep 2

echo "Done Installing Thermal Service"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
