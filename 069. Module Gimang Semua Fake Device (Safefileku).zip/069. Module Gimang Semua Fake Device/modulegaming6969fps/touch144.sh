[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Surface Flinger Improvement"

sleep 2

set_touch() {
settings put systemui min_refresh_rate_for_fps_boost 144 
settings put systemui max_refresh_rate_for_fps_boost 144 
settings put systemui peak_refresh_rate 144.0 
settings put systemui min_refresh_rate 144.0 
settings put system min_refresh_rate_for_fps_boost 144 
settings put system max_refresh_rate_for_fps_boost 144 
settings put system peak_refresh_rate 144.0 
settings put system min_refresh_rate 144.0 
settings put systemui tran_need_recovery_refresh_mode 144 
settings put systemui last_tran_refresh_mode_in_refresh_setting 144 
settings put systemui tran_refresh_mode 144 
settings put system tran_need_recovery_refresh_mode 144 
settings put system last_tran_refresh_mode_in_refresh_setting 144 
settings put system tran_refresh_mode 144 
settings put global burn_in_protection 0 
}

set_touch > /dev/null 2>&1 

#Tweaks
set_surface() {
setprop debug.touchscreen.latency.scale 0.5 
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 144 
setprop debug.hwui.profile.maxframes 144 
setprop debug.javafx.animation.fullspeed 1 
setprop debug.javafx.animation.framerate 144 
setprop debug.redroid.fps 144 
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 1 
setprop debug.sf.hwc_hdcp_via_neg_vsync 1 
setprop debug.sf.set_binder_thread_rt 1 
setprop debug.sf.showcpu 0 
setprop debug.sf.showupdates 0 
setprop debug.sf.showbackground 0 
setprop debug.sf.showfps 0 
setprop debug.sf.hw 0 
setprop debug.sf.enable_hgl 0 
setprop debug.sf.ddms 1 
setprop debug.sf.dump 0 
setprop debug.sf.set_idle_timer_ms 0 
setprop debug.sf.treat_170m_as_sRGB 0 
setprop debug.sf.max_igbp_list_size 0 
setprop debug.sf.disable_hwc_vds 1 
setprop debug.sf.enable_egl_image_tracker 0 
setprop debug.sf.luma_sampling 1 
setprop debug.sf.disable_client_composition_cache 1 
setprop debug.sf.enable_advanced_sf_phase_offset 0 
setprop debug.sf.enable_gl_backpressure 0 
setprop debug.sf.disable_backpressure 1 
setprop debug.sf.latch_unsignaled 0 
setprop debug.sf.gpu_freq_index 7 
setprop debug.sf.auto_latch_unsignaled 0 
setprop debug.sf.enable_hwc_vds 0 
setprop debug.sf.show_predicted_vsync 0 
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.kernel_idle_timer_update_overlay 1 
setprop debug.sf.support_kernel_idle_timer_enabled 0 
setprop debug.sf.vsync_reactor_ignore_present_fences 0 
setprop debug.sf.enable_transaction_tracing 0 
setprop debug.sf.use_phase_offsets_as_durations 0 
setprop debug.sf.ignore_hwc_physical_display_orientation 0 
setprop debug.sf.enable_adpf_cpu_hint 1 
setprop debug.sf.frame_rate_multiple_threshold 144 
setprop debug.sf_frame_rate_multiple_fences 144 
setprop debug.sf.early.app.duration 20000000 
setprop debug.sf.early.sf.duration 27600000 
setprop debug.sf.hwc.min.duration 23000000 
setprop debug.sf.late.app.duration 20000000 
setprop debug.sf.late.sf.duration 27600000 
setprop debug.sf.earlyGl.sf.duration 27600000 
setprop debug.sf.144_fps.early.app.duration 8333333 
setprop debug.sf.144_fps.early.sf.duration 11500000 
setprop debug.sf.144_fps.earlyGl.app.duration 8333333 
setprop debug.sf.144_fps.earlyGl.sf.duration 11500000 
setprop debug.sf.144_fps.late.app.duration 8333333 
setprop debug.sf.144_fps.late.sf.duration 11500000 
setprop debug.sf.high_fps.early.app.duration 10000000 
setprop debug.sf.high_fps.early.sf.duration 13800000 
setprop debug.sf.high_fps.earlyGl.app.duration 10000000 
setprop debug.sf.high_fps.earlyGl.sf.duration 13800000 
setprop debug.sf.high_fps.late.app.duration 10000000 
setprop debug.sf.high_fps.late.sf.duration 13800000 
setprop debug.sf.high_fps.hwc.min.duration 8500000 
setprop debug.sf.high_fps_early_phase_offset_ns 6100000 
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000 
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000 
setprop debug.sf.earlyGl.app.duration 20000000 
setprop debug.sf.early_gl_phase_offset_ns 3000000 
setprop debug.sf.early_gl_app_phase_offset_ns 15000000 
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000 
setprop debug.sf.early_phase_offset_ns 500000 
}
set_surface > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#Surface Flinger
set_surface() {
properties=(
  "debug.sf.disable_backpressure 1"
  "debug.sf.hwc_hotplug_error_via_neg_vsync 1"
  "debug.sf.hwc_hdcp_via_neg_vsync 1"
  "debug.sf.set_binder_thread_rt 1"
  "debug.sf.gpu_freq_index 7"
  "debug.sf.ignore_hwc_physical_display_orientation 0"
  "debug.sf.enable_adpf_cpu_hint 1"
  "debug.sf.latch_unsignaled 0"
  "debug.sf.enable_hwc_vds 0"
  "debug.sf.disable_hwc_vds 1"
  "debug.sf.frame_rate_multiple_threshold 144"
  "debug.sf_frame_rate_multiple_fences 144"
  "debug.sf.enable_egl_image_tracker 0"
  "debug.sf.luma_sampling 1"
  "debug.sf.early_phase_offset_ns 500000"
  "debug.sf.auto_latch_unsignaled 0"
  "debug.sf.early.app.duration 20000000"
  "debug.sf.early.sf.duration 27600000"
  "debug.sf.earlyGl.app.duration 20000000"
  "debug.sf.earlyGl.sf.duration 27600000"
  "debug.sf.late.app.duration 20000000"
  "debug.sf.late.sf.duration 27600000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.hwc.min.duration 23000000"
  "debug.sf.enable_gl_backpressure 0"
  "debug.sf.enable_transaction_tracing false"
  "debug.sf.enable_hgl 0"
  "debug.sf.ddms 1"
  "debug.sf.dump 0"
  "debug.sf.max_igbp_list_size 0"
  "debug.sf.showupdates 0"
  "debug.sf.showcpu 0"
  "debug.sf.showbackground 0"
  "debug.sf.showfps 0"
  "debug.sf.hw 0"
  "debug.sf.disable_client_composition_cache 1"
  "debug.sf.enable_advanced_sf_phase_offset 0"
  "debug.sf.use_phase_offsets_as_durations 0"
  "debug.sf.predict_hwc_composition_strategy 0"
  "debug.sf.treat_170m_as_sRGB 0"
  "debug.sf.set_idle_timer_ms 0"
  "debug.sf.early_gl_phase_offset_ns 3000000"
  "debug.sf.early_gl_app_phase_offset_ns 15000000"
  "debug.sf.high_fps_early_phase_offset_ns 6100000"
  "debug.sf.high_fps_early_gl_phase_offset_ns 650000"
  "debug.sf.high_fps_late_app_phase_offset_ns 100000"
  "debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000"
  "debug.sf.144_fps.early.app.duration 8333333"
  "debug.sf.144_fps.early.sf.duration 11500000"
  "debug.sf.144_fps.earlyGl.app.duration 8333333"
  "debug.sf.144_fps.earlyGl.sf.duration 11500000"
  "debug.sf.144_fps.late.app.duration 8333333"
  "debug.sf.144_fps.late.sf.duration 11500000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.high_fps.late.app.duration 10000000"
  "debug.sf.high_fps.early.sf.duration 13800000"
  "debug.sf.high_fps.early.app.duration 10000000"
  "debug.sf.high_fps.earlyGl.sf.duration 13800000"
  "debug.sf.high_fps.earlyGl.app.duration 10000000"
  "debug.sf.high_fps.hwc.min.duration 8500000"
)

for prop in "${properties[@]}"; do
  setprop $prop
done
}
set_surface > /dev/null 2>&1 

#Other
(
  settings put global window_animation_scale 0.5 
  settings put global transition_animation_scale 0.5 
  settings put global animator_duration_scale 0.5 
)> /dev/null 2>&1 

set_surface() {
settings put surfaceflinger refresh_rate 144 
settings put surfaceflinger max_frame_buffer_acquired_count 3 
settings put surfaceflinger use_content_detection_for_refresh_rate 1  
settings put surfaceflinger game_default_frame_rate_override 144 
settings put surfaceflinger enable_frame_rate_override 0  
settings put surfaceflinger has_HDR_display 0 
settings put surfaceflinger supports_background_blur 1 
settings put surfaceflinger primary_display_orientation 0  
settings put surfaceflinger force_hwc_copy_for_virtual_displays 0 
settings put surfaceflinger protected_contents 1  
settings put surfaceflinger uclamp.min 130 
settings put surfaceflinger has_wide_color_display 0 
settings put surfaceflinger use_color_management 0 
settings put surfaceflinger set_touch_timer_ms 0 
settings put surfaceflinger max_virtual_display_dimension 4096 
settings put surfaceflinger wcg_composition_dataspace 143261696 
settings put surfaceflinger clear_slots_with_set_layer_buffer 0 
settings put surfaceflinger set_idle_timer_ms 0 
settings put surfaceflinger set_display_power_timer_ms 0 
settings put surfaceflinger enable_hwc 0 
settings put surfaceflinger min_swap_interval 0 
settings put surfaceflinger disable_expensive_timestamps 1 
settings put surfaceflinger enable_vds_tweak 0 
settings put surfaceflinger vsync_eventphase_offset_ns 6300000 
settings put surfaceflinger vsync_sfoffset_ns 6300000 
settings put surfaceflinger enable_debug_sf_vs 0 
sertings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.sampling_profiler 1
settings put global persist.sys.scrollingcache 2 
settings put global persist.sys.fps_unlock_allowed 144 
settings put global sys.fps_unlock_allowed 144 
settings put global persist.sys.ui.hw 1 
settings put global persist.sys.perf.topAppRenderThreadBoost.enable 1 
settings put global persist.device_config.surface_flinger_native_boot.SkiaTracingFeature__use_skia_tracing 0 
settings put global persist.sys.ui.hw 1 
settings put global persist.vendor.color.matrix 2 
settings put global persist.sys.minfree_6g 16384,20480,32768,131072,230400,286720 
settings put global persist.sys.minfree_8g 16384,20480,32768,131072,384000,524288 
settings put global persist.sys.minfree_12g 16384,20480,131072,384000,524288,819200 
settings put global persist.sys.minfree_def 16384,20480,32768,131072,230400,286720 
settings put global persist.vendor.qti.inputopts.enable 1 
settings put global persist.vendor.qti.inputopts.movetouchslop 1 
settings put global persist.sys.NV_FPSLIMIT 144 
settings put global persist.sys.NV_POWERMODE 1 
settings put global persist.sys.NV_PROFVER 15 
settings put global persist.sys.NV_STEREOCTRL 0 
settings put global persist.sys.NV_STEREOSEPCHG 0 
settings put global persist.sys.NV_STEREOSEP 20 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.device_config.nnapi_native.current_feature_level 7 
settings put global persist.device_config.nnapi_native.telemetry_enable 0 
settings put global persist.device_config.runtime_native.metrics.reporting-mods 2 
settings put global persist.device_config.runtime_native.metrics.reporting-mods-server 2 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods 100 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods-server 100 
settings put global persist.device_config.runtime_native.metrics.reporting-spec 1,5,30,60,600 
settings put global persist.device_config.runtime_native.metrics.reporting-spec-server 1,10,60,3600,*
settings put global persist.device_config.runtime_native.metrics.write-to-statsd 1 
settings put global persist.device_config.runtime_native.usap_pool_size_max 0 
settings put global persist.device_config.runtime_native.use_app_image_startup_cache 1 
settings put global persist.device_config.runtime_native_boot.disable_lock_profiling 0 
settings put global persist.device_config.runtime_native_boot.enable_uffd_gc_2 0 
settings put global persist.device_config.runtime_native_boot.iorap_blacklisted_packages 0 
settings put global persist.device_config.runtime_native_boot.iorap_perfetto_enable 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0 
settings put global persist.device_config.runtime_native_boot.iorapd_options 0 
settings put global persist.device_config.tethering.bpf_net_maps_enable_java_bpf_map 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0
}

set_surface > /dev/null 2>&1 

#AndroidConfig
set_android() {
cmd device_config put surfaceflinger refresh_rate 144 
cmd device_config put surfaceflinger max_frame_buffer_acquired_count 3 
cmd device_config put surfaceflinger use_content_detection_for_refresh_rate 1 
cmd device_config put surfaceflinger game_default_frame_rate_override 144  
cmd device_config put surfaceflinger enable_frame_rate_override 0 
cmd device_config put surfaceflinger has_HDR_display 0 
cmd device_config put surfaceflinger supports_background_blur 1 
cmd device_config put surfaceflinger primary_display_orientation 0 
cmd device_config put surfaceflinger force_hwc_copy_for_virtual_displays 0 
cmd device_config put surfaceflinger protected_contents 1 
cmd device_config put surfaceflinger uclamp.min 130 
cmd device_config put surfaceflinger has_wide_color_display 0 
cmd device_config put surfaceflinger use_color_management 0 
cmd device_config put surfaceflinger set_touch_timer_ms 0 
cmd device_config put surfaceflinger max_virtual_display_dimension 4096 
cmd device_config put surfaceflinger wcg_composition_dataspace 143261696 
cmd device_config put surfaceflinger clear_slots_with_set_layer_buffer 0 
cmd device_config put surfaceflinger set_idle_timer_ms 0 
cmd device_config put surfaceflinger set_display_power_timer_ms 0 
cmd device_config put surfaceflinger enable_hwc 0 
cmd device_config put surfaceflinger min_swap_interval 0 
cmd device_config put surfaceflinger disable_expensive_timestamps 1 
cmd device_config put surfaceflinger enable_vds_tweak 0 
cmd device_config put surfaceflinger vsync_eventphase_offset_ns 6300000 
cmd device_config put surfaceflinger vsync_sfoffset_ns 6300000 
cmd device_config put surfaceflinger enable_debug_sf_vs 0 
}
set_android > /dev/null 2>&1 

sleep 2

echo "Done Installing Surface Flinger Improvement"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
