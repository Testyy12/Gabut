[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Tweak Angle"

sleep 2

#Tweaks
set_tweakangle() {
setprop angle.supported 1 
setprop angle_gl_driver_all_angle 1 
setprop angle_gl_driver_selection_values angle 
setprop angle_debug_package org.chromium.angle 
setprop angle_debug_package com.activision.callofduty.warzone 
setprop angle_debug_package org.chromium.angle 
setprop angle_debug_package com.mobilelegends.mi 
setprop angle_debug_package com.pubg.krmobile 
setprop angle_debug_package com.proximabeta.mf.uamo 
setprop angle_debug_package com.proximabeta.mf.liteuamo 
setprop angle_debug_package com.netease.newspike 
setprop angle_debug_package com.garena.game.codm 
setprop angle_debug_package com.carxtech.sr 
setprop angle_debug_package jp.konami.pesam 
setprop angle_debug_package com.miraclegames.farlight84 
setprop angle_debug_package com.ea.gp.fifamobile 
setprop angle_debug_package com.dts.freefireth 
setprop angle_debug_package com.dts.freefiremax 
setprop angle_debug_package com.miHoYo.GenshinImpact 
setprop angle_debug_package com.levelinfinite.sgameGlobal 
setprop angle_debug_package com.mobile.legends 
setprop angle_debug_package com.tencent.ig 
setprop angle_debug_package com.tencent.iglite 
setprop angle_debug_package com.GlobalSoFunny.Sausage 
setprop angle_debug_package com.kurogame.wutheringwaves.global 
setprop angle_debug_package flar2.devcheck 
setprop angle_debug_package ru.andr7e.deviceinfohw 
setprop angle_debug_package com.finalwire.aida64 
setprop angle_debug_package com.riotgames.league.wildrift 
setprop angle_enabled_app com.activision.callofduty.warzone 
setprop angle_enabled_app com.riotgames.league.wildrift 
setprop angle_enabled_app com.mobilelegends.mi 
setprop angle_enabled_app com.pubg.krmobile 
setprop angle_enabled_app com.proximabeta.mf.uamo 
setprop angle_enabled_app com.proximabeta.mf.liteuamo 
setprop angle_enabled_app com.netease.newspike 
setprop angle_enabled_app com.garena.game.codm 
setprop angle_enabled_app com.carxtech.sr 
setprop angle_enabled_app jp.konami.pesam 
setprop angle_enabled_app com.miraclegames.farlight84 
setprop angle_enabled_app com.ea.gp.fifamobile 
setprop angle_enabled_app com.dts.freefireth 
setprop angle_enabled_app com.dts.freefiremax 
setprop angle_enabled_app com.miHoYo.GenshinImpact 
setprop angle_enabled_app com.levelinfinite.sgameGlobal 
setprop angle_enabled_app com.mobile.legends 
setprop angle_enabled_app com.tencent.ig 
setprop angle_enabled_app com.tencent.iglite 
setprop angle_enabled_app com.GlobalSoFunny.Sausage 
setprop angle_enabled_app com.kurogame.wutheringwaves.global 
setprop angle_enabled_app flar2.devcheck 
setprop angle_enabled_app ru.andr7e.deviceinfohw 
setprop angle_enabled_app com.finalwire.aida64 
setprop debug.angle.markers 1 
setprop debug.angle.capture.enabled 1 
setprop debug.angle.capture.out_dir foo 
setprop debug.angle.capture.frame_start 0 
setprop debug.angle.capture.label bar 
setprop debug.angle.capture.trigger 20 
setprop debug.angle.capture.frame_end 200 
setprop debug.angle.backend 2 
setprop debug.angle.overlay FPS:Vulkan*PipelineCache* 
setprop debug.angle.feature_overrides_enabled preferLinearFilterForYUV:mapUnspecifiedColorSpaceToPassThrough 
setprop debug.angle.enable_vulkan_api_dump_layer 1 
setprop debug.apidump.detailed 1 
setprop debug.gles.angle 1 
setprop debug.gralloc.gfx_ubwc_disable 1 
}
set_tweakangle > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#DeviceConfig
set_android() {
cmd device_config put gfx angle.supported 1 
cmd device_config put graphics angle.supported 1 
cmd device_config put driver angle.supported 1 
cmd device_config put global angle.supported 1 
cmd device_config put global angle_gl_driver_all_angle 1 
cmd device_config put global angle_gl_driver_selection_values angle 
cmd device_config put global angle_enabled_app com.activision.callofduty.warzone 
cmd device_config put global angle_debug_package com.activision.callofduty.warzone 
cmd device_config put global angle_debug_package org.chromium.angle 
cmd device_config put global angle_debug_package com.mobilelegends.mi 
cmd device_config put global angle_debug_package com.pubg.krmobile 
cmd device_config put global angle_debug_package com.proximabeta.mf.uamo 
cmd device_config put global angle_debug_package com.proximabeta.mf.liteuamo 
cmd device_config put global angle_debug_package com.netease.newspike 
cmd device_config put global angle_debug_package com.garena.game.codm 
cmd device_config put global angle_debug_package com.carxtech.sr 
cmd device_config put global angle_debug_package jp.konami.pesam 
cmd device_config put global angle_debug_package com.miraclegames.farlight84 
cmd device_config put global angle_debug_package com.ea.gp.fifamobile 
cmd device_config put global angle_debug_package com.dts.freefireth 
cmd device_config put global angle_debug_package com.dts.freefiremax 
cmd device_config put global angle_debug_package com.miHoYo.GenshinImpact 
cmd device_config put global angle_debug_package com.levelinfinite.sgameGlobal 
cmd device_config put global angle_debug_package com.mobile.legends 
cmd device_config put global angle_debug_package com.tencent.ig 
cmd device_config put global angle_debug_package com.tencent.iglite 
cmd device_config put global angle_debug_package com.GlobalSoFunny.Sausage 
cmd device_config put global angle_debug_package com.kurogame.wutheringwaves.global 
cmd device_config put global angle_debug_package flar2.devcheck 
cmd device_config put global angle_debug_package ru.andr7e.deviceinfohw 
cmd device_config put global angle_debug_package com.finalwire.aida64 
cmd device_config put global angle_debug_package com.riotgames.league.wildrift 
cmd device_config put global angle_enabled_app com.riotgames.league.wildrift 
cmd device_config put global angle_enabled_app com.mobilelegends.mi 
cmd device_config put global angle_enabled_app com.pubg.krmobile 
cmd device_config put global angle_enabled_app com.proximabeta.mf.uamo 
cmd device_config put global angle_enabled_app com.proximabeta.mf.liteuamo 
cmd device_config put global angle_enabled_app com.netease.newspike 
cmd device_config put global angle_enabled_app com.garena.game.codm 
cmd device_config put global angle_enabled_app com.carxtech.sr 
cmd device_config put global angle_enabled_app jp.konami.pesam 
cmd device_config put global angle_enabled_app com.miraclegames.farlight84 
cmd device_config put global angle_enabled_app com.ea.gp.fifamobile 
cmd device_config put global angle_enabled_app com.dts.freefireth 
cmd device_config put global angle_enabled_app com.dts.freefiremax 
cmd device_config put global angle_enabled_app com.miHoYo.GenshinImpact 
cmd device_config put global angle_enabled_app com.levelinfinite.sgameGlobal 
cmd device_config put global angle_enabled_app com.mobile.legends 
cmd device_config put global angle_enabled_app com.tencent.ig 
cmd device_config put global angle_enabled_app com.tencent.iglite 
cmd device_config put global angle_enabled_app com.GlobalSoFunny.Sausage 
cmd device_config put global angle_enabled_app com.kurogame.wutheringwaves.global 
cmd device_config put global angle_enabled_app flar2.devcheck 
cmd device_config put global angle_enabled_app ru.andr7e.deviceinfohw 
cmd device_config put global angle_enabled_app com.finalwire.aida64 
}
set_android > /dev/null 2>&1 

sleep 2

echo "Done Installing Tweak Angle"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
