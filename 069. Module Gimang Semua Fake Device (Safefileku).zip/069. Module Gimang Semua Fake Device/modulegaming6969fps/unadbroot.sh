if [ "$(id -u)" -ne 2000 ]; then
    echo "[Error | @HenVx | Hendi]"
    exit 1
fi

nohup sh /sdcard/modulegaming6969fps/android/system > /dev/null &

echo ""
echo "
Module Gaming iPhone 69 Pro Max
╔═╦╗╔╦╗╔═╦═╦╦╦╦╗╔═╗
║╚╣║║║╚╣╚╣╔╣╔╣║╚╣═╣
╠╗║╚╝║║╠╗║╚╣║║║║║═╣
╚═╩══╩═╩═╩═╩╝╚╩═╩═╝
@modulegaming6969fps
"
echo ""
echo " Version 6.9 2024 "
echo " Dev : HenVx | @modulegaming6969fps "
echo " Instal Proses Wait "
echo ""

sleep 0.5
echo " Remove Module Gaming  ! ! "
echo ""
sleep 5
echo " [■□□□□□□□□□]  "
sleep 2
echo " [■■□□□□□□□□]  "
sleep 2
echo " [■■■□□□□□□□]  "
sleep 2
echo " [■■■■□□□□□□]  "
sleep 2
echo " [■■■■■□□□□□]  "
sleep 2
echo " [■■■■■■□□□□]  "
sleep 2
echo " [■■■■■■■□□□]  "
sleep 2
echo " [■■■■■■■■□□]  "
sleep 2
echo " [■■■■■■■■■□] "
sleep 0.5
echo ""
echo " Succes Removed Module Gaming "
echo ""