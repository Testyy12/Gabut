[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      vivo X100 Ultra      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing Fake Device"

sleep 2

fake_device() {
settings put global device_name vivo-X100-Ultra
settings put global device_device PD2366 
settings put global device_model V2366HA 
settings put global device_brand vivo 
settings put global device_manufacturer vivo 
settings put global persist.sys.tran.device.name vivo X100 Ultra
}

fake_device > /dev/null 2>&1 

sleep 2

echo "Done Installing Fake Device"

sleep 2

echo "Selamat Gimang 6969 Ngefies"
