[ "$(id -u)" -ne 2000 ] && echo "No shell permissions." && exit 1

echo ""
echo "**************************************"
echo "*   @modulegaming6969ngefies   *"
echo "**************************************"
echo "*      iPhone 69 Pro Max      *"
echo "**************************************"
echo ""

sleep 2

echo "Installing vulkan"

sleep 2

#Tweaks
set_vulkan() {
setprop debug.hwui.multi_renderer.use 1 
setprop debug.hwui.shadow.renderer vulkan 
setprop debug.hwui.renderer vulkan 
setprop debug.renderengine.backend vulkan 
setprop debug.composition.type vulkan 
setprop debug.vulkan.layers VK_LAYER_GOOGLE_threading 
setprop debug.vulkan.layers VK_LAYER_LUNARG_parameter_validation 
setprop debug.vulkan.layers VK_LAYER_LUNARG_object_tracker 
setprop debug.vulkan.layers VK_LAYER_LUNARG_core_validation 
setprop debug.vulkan.layers VK_LAYER_LUNARG_image 
setprop debug.vulkan.layers VK_LAYER_LUNARG_swapchain 
setprop debug.vulkan.layers VK_LAYER_GOOGLE_unique_objects 
}
set_vulkan > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

compotision_type() {
settings put global persist.sys.composition.type vulkan 
}

compotision_type > /dev/null 2>&1 

sleep 2

echo "Done Installing vulkan"

sleep 2

echo "Selamat Gaming 696969 Ngefies"
