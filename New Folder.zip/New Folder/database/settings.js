const fs = require("fs");

global.merchant = "OK1336194"
global.codeqr = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214504408354149080303UMI51440014ID.CO.QRIS.WWW0215ID20232921390780303UMI5204541153033605802ID5920UCUP STORE OK13361946005BLORA61055821162070703A0163048635"
global.keyorkut = "255791017216147211336194OKCTB4171141D12D5411CD8E7FE5D4098CDA"
global.MERCHANT = '';
global.PIN = '';
global.PASSWORD = '';
global.urlrafael = 'https://panelprivate.burgercraft.xyz' // isi domain panel anda
global.apikey2 = 'ptla_5ON7DKTzYNnWD1ujGjTjvBFu9li42GNtjRqBULsfTiZ'
global.capikey = 'ptlc_anKZAk38V46c2TmvQKNEgv8ZscgFTf1VgIi7XWaDVvm'
global.egg = "15"
global.loc = "1"
global.thumb = 'https://8030.us.kg/file/HQbeXyUZePYA.jpg'
global.namastore = "𝙍𝙖𝙛𝙖𝙚𝙡 𝙎𝙩𝙤𝙧𝙚"
