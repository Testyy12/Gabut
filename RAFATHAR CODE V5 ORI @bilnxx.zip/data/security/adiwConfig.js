module.exports = {
  'approval': {
    'num': '6285938355637',
    'text': "setujui",
    'set': "👀 Harus mendapatkan persetujuan oleh creator script, Jika ingin memakai script ini",
    'greet': "*Disetujui Oleh Creator, Silahkan Restart Panel Atau Run Ulang script* ☠️ "
  },
  'creatorScript': '6285938355637',
  'filePath': "./data/approval",
  'checkFilePath': "./rafatharcode.js",
  'codeToDetect': 'connectToWhatsApp();'
};