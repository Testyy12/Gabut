<?php
if($data_user['level'] == 'Admin') li('Admin','feather icon-bookmark warning','/admin');
li('Home','fa fa-home','/');
if($data_user['level'] != 'Basic') ul([
    'name' => 'Premium',
    'icon' => 'fi-briefcase',
    'content' => [
        ['name' => 'Transfer Balance','page' => '/premium/transfer'],
        ['name' => 'Make a Voucher','page' => '/premium/voucher'],
        ['name' => 'My Downline','page' => '/premium/downline'],
    ]
]);
if(conf('xtra-fitur',4) == 'true') ul([
    'name' => 'Papan Peringkat',
    'icon' => 'fa fa-trophy',
    'content' => [
        (conf('xtra-fitur',3) == 'true') ? ['name' => 'Social Media','page' => '/page/monthly-rating/social-media'] : '',
    ]
]);
ul([
    'name' => 'Sosial Media',
    'icon' => 'mdi mdi-cart',
    'content' => [
        ['name' => 'Sosial Media 1','page' => '/order/social-media'],
        ['name' => 'Sosial Media 2','page' => '/order/social-media-2'],
        ['name' => 'Sosial Media 3','page' => '/order/social-media-3'],
        ['name' => 'Riwayat','page' => '/order/history/social-media'],
    ]
]);
li('Daftar Harga','mdi mdi-tag','/page/product');
ul([
    'name' => 'Deposit',
    'icon' => 'mdi mdi-bank',
    'content' => [
        ['name' => 'New','page' => '/deposit/new'],
        ['name' => 'Voucher','page' => '/deposit/voucher'],
        ['name' => 'Riwayat','page' => '/deposit/history'],
    ]
]);
ul([
    'name' => 'Halaman',
    'icon' => 'mdi mdi-sitemap',
    'content' => [
        ['name' => 'Information Center','page' => '/page/information'],
        ['name' => 'Terms of Service','page' => '/page/terms-of-service'],
        ['name' => 'General Questions','page' => '/page/general-questions'],
        ['name' => 'Contact Admin','page' => '/page/contact'],
    ]
]);

ul([
    'name' => 'API Documentation',
    'icon' => 'mdi mdi-code-tags',
    'content' => [
        ['name' => 'Social Media','page' => '/page/api/social-media'],
        ['name' => 'Social Media 2','page' => '/page/api/social-media-2'],
        (conf('xtra-fitur',1) == 'true') ? ['name' => 'Social Media 2','page' => '/page/api/social-media-3'] : '',
        // (conf('xtra-fitur',3) == 'true') ? ['name' => 'Social Media','page' => '/page/api/social-media'] : '',
        // (conf('xtra-fitur',2) == 'true') ? ['name' => 'Game Feature','page' => '/page/api/game-feature'] : '',
    ]
]);
?>