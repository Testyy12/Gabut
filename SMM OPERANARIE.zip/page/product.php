<?php 
require '../connect.php';
require _DIR_('library/session/session');
require _DIR_('library/layout/header.user');
?>
<section id="basic-datatable">
    <div class="row">
        <div class="col-12">
            <div class="card overflow-hidden">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="feather icon-tag"></i>
                        Product List
                    </h4>
                </div>
                <div class="card-body card-dashboard">
                    <ul class="nav nav-tabs nav-fill" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="profile-tab-fill" data-toggle="tab" href="#sosmed" role="tab" aria-controls="sosmed" aria-selected="false">Sosmed</a>
                        </li>
                        <? if(conf('xtra-fitur',3) == 'true') { ?>
                        <li class="nav-item">
                            <a class="nav-link" id="home-tab-fill" data-toggle="tab" href="#sosmed-2" role="tab" aria-controls="sosmed-2" aria-selected="false">Sosmed 2</a>
                        </li>
                        <? } if(conf('xtra-fitur',2) == 'true') { ?>
                        <li class="nav-item">
                            <a class="nav-link" id="home-tab-fill" data-toggle="tab" href="#sosmed-3" role="tab" aria-controls="sosmed-3" aria-selected="false">Sosmed 3</a>
                        </li>
                        <? } ?>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane show active" id="sosmed">
                            <form role="form" method="POST">
                                <div class="row">
                                    <div class="form-group col-12">
                                        <select class="form-control" id="categorysosmed" name="categorysosmed">
                                            <option value="0" selected disabled>- Select One -</option>
                                            <?php
                                            $search = $call->query("SELECT code, name FROM category WHERE `order` = 'social' ORDER BY name ASC");
                                            if($search->num_rows > 0) {
                                                while($row = $search->fetch_assoc()) {
                                                    print '<option value="'.$row['code'].'">'.$row['name'].'</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped zero-configuration mb-0">
                                        <thead>
                                            <tr>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">ID</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Name</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Min</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Max</th>
                                                <th class="text-center" colspan="2" style="vertical-align:middle">Price/K</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Status</th>
                                            </tr>
                                            <tr>
                                                <th class="text-center">Basic</th>
                                                <th class="text-center">Premium</th>
                                            </tr>
                                        </thead>
                                        <tbody id="pricelist1">
                                            <tr>
                                                <td colspan="6" class="text-center">Please select a category.</td>
                                                <td class="text-center text-danger"><i class="far fa-times-circle"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                        <? if(conf('xtra-fitur',3) == 'true') { ?>
                        <div class="tab-pane" id="sosmed-2">
                            <form role="form" method="POST">
                                <div class="row">
                                    <div class="form-group col-12">
                                        <select class="form-control" id="categorysosmed-2" name="categorysosmed-2">
                                            <option value="0" selected disabled>- Select One -</option>
                                            <?php
                                            $search = $call->query("SELECT code, name FROM category_2 WHERE `order` = 'social' ORDER BY name ASC");
                                            if($search->num_rows > 0) {
                                                while($row = $search->fetch_assoc()) {
                                                    print '<option value="'.$row['code'].'">'.$row['name'].'</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped zero-configuration mb-0">
                                        <thead>
                                            <tr>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">ID</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Name</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Min</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Max</th>
                                                <th class="text-center" colspan="2" style="vertical-align:middle">Price/K</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Status</th>
                                            </tr>
                                            <tr>
                                                <th class="text-center">Basic</th>
                                                <th class="text-center">Premium</th>
                                            </tr>
                                        </thead>
                                        <tbody id="pricelist2">
                                            <tr>
                                                <td colspan="6" class="text-center">Please select a category.</td>
                                                <td class="text-center text-danger"><i class="far fa-times-circle"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                        <? } if(conf('xtra-fitur',2) == 'true') { ?>
                            <div class="tab-pane" id="sosmed-3">
                            <form role="form" method="POST">
                                <div class="row">
                                    <div class="form-group col-12">
                                        <select class="form-control" id="categorysosmed-3" name="categorysosmed-3">
                                            <option value="0" selected disabled>- Select One -</option>
                                            <?php
                                            $search = $call->query("SELECT code, name FROM category_3 WHERE `order` = 'social' ORDER BY name ASC");
                                            if($search->num_rows > 0) {
                                                while($row = $search->fetch_assoc()) {
                                                    print '<option value="'.$row['code'].'">'.$row['name'].'</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped zero-configuration mb-0">
                                        <thead>
                                            <tr>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">ID</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Name</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Min</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Max</th>
                                                <th class="text-center" colspan="2" style="vertical-align:middle">Price/K</th>
                                                <th class="text-center" rowspan="2" style="vertical-align:middle">Status</th>
                                            </tr>
                                            <tr>
                                                <th class="text-center">Basic</th>
                                                <th class="text-center">Premium</th>
                                            </tr>
                                        </thead>
                                        <tbody id="pricelist3">
                                            <tr>
                                                <td colspan="6" class="text-center">Please select a category.</td>
                                                <td class="text-center text-danger"><i class="far fa-times-circle"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                        <? } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<? require _DIR_('library/layout/footer.user'); ?>
<script type="text/javascript">
$(document).ready(function() {
    $("#categorysosmed").change(function() {
        var sosmed = $("#categorysosmed").val();
        $.ajax({
            url: '<?= ajaxlib('price-list') ?>',
            data: 'category=' + sosmed + '&type=socmed&csrf_token=<?= $csrf_string ?>',
            type: 'POST',
            dataType: 'html',
            success: function(msg) {
                $("#pricelist1").html(msg);
            } 
        });
    });
    $("#categorysosmed-2").change(function() {
        var sosmed = $("#categorysosmed-2").val();
        $.ajax({
            url: '<?= ajaxlib('price-list') ?>',
            data: 'category=' + sosmed + '&type=socmed-2&csrf_token=<?= $csrf_string ?>',
            type: 'POST',
            dataType: 'html',
            success: function(msg) {
                $("#pricelist2").html(msg);
            } 
        });
    });
    $("#categorysosmed-3").change(function() {
        var sosmed = $("#categorysosmed-3").val();
        $.ajax({
            url: '<?= ajaxlib('price-list') ?>',
            data: 'category=' + sosmed + '&type=socmed-3&csrf_token=<?= $csrf_string ?>',
            type: 'POST',
            dataType: 'html',
            success: function(msg) {
                $("#pricelist3").html(msg);
            } 
        });
    });
    $("#provpulsa").change(function() {
        var typepulsa = $("#provpulsa").val();
        $.ajax({
            url: '<?= ajaxlib('category-pulsa') ?>',
            data: 'type=' + typepulsa + '&csrf_token=<?= $csrf_string ?>',
            type: 'POST',
            dataType: 'html',
            success: function(msg) {
                $("#categorypulsa").html(msg);
            }
        });
    });
    $("#categorypulsa").change(function() {
        var pulsa = $("#provpulsa").val();
        var brand = $("#categorypulsa").val();
        $.ajax({
            url: '<?= ajaxlib('price-list') ?>',
            data: 'category=' + pulsa + '&brand=' + brand + '&type=ppob&csrf_token=<?= $csrf_string ?>',
            type: 'POST',
            dataType: 'html',
            success: function(msg) {
                $("#pricelist2").html(msg);
            }
        });
    });
    $("#categorygames").change(function() {
        var games = $("#categorygames").val();
        $.ajax({
            url: '<?= ajaxlib('price-list') ?>',
            data: 'category=' + games + '&type=games&csrf_token=<?= $csrf_string ?>',
            type: 'POST',
            dataType: 'html',
            success: function(msg) {
                $("#pricelist3").html(msg);
            } 
        });
    });
});
</script>